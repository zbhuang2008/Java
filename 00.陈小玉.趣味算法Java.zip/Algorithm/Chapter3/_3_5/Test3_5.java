package Algorithm.Chapter3._3_5;
/*3.5效率至上——大整数乘法*/

import java.util.Scanner;

public class Test3_5 {
    static final int M=100;     //预设字符数组长度
    static String sa;
    static String sb;

    /*结点类*/
    static class Node{
        int[] s=new int[M];
        int l;      //代表字符串的长度
        int c;
    }

    static void cp(Node src,Node des,int st,int l){
        for (int i=st,j=0; i<st+l; i++,j++){
            des.s[j] = src.s[i];
        }
        des.l=l;
        des.c=st+src.c;             //次幂
    }

    static void add(Node pa,Node pb,Node ans){
        int i,cc,k,palen,pblen,len;
        int ta,tb;

        if (pa.c < pb.c){       //交换两个结点
            Node temp = pa;
            pa=pb;
            pb=temp;
        }
        ans.c=pb.c;
        cc=0;
        palen=pa.l + pa.c;
        pblen=pb.l + pb.c;

        if (palen > pblen){
            len = palen;
        }else{
            len = pblen;
        }

        k = pa.c - pb.c;

        for (i=0;i<len-ans.c; i++){
            if (i<k)
                ta=0;
            else
                ta=pa.s[i-k];
            if (i<pb.l)
                tb=pb.s[i];
            else
                tb=0;
            if (i>=pa.l+k)
                ta=0;
            ans.s[i] = (ta + tb + cc)%10;
            cc=(ta + tb + cc)/10;
        }
        if (cc!=0){
            ans.s[i++] = cc;
        }
        ans.l=i;
    }

    static void mul(Node pa,Node pb,Node ans){
        int i,cc,w;
        int ma = pa.l>>1;   //长度除以2
        int mb = pb.l>>1;

        //初始化结点
        Node ah=new Node(),al=new Node(),bh=new Node(),bl=new Node(),
             t1=new Node(),t2=new Node(),t3=new Node(),t4=new Node(),
             z=new Node();

        if (ma==0 || mb==0){    //如果其中个数为0
            if (ma==0){         //如果a串的长度为0，pa,pb交换，pa的长度大于等于pb的长度
                Node temp=pa;
                pa=pb;
                pb=temp;
            }
            ans.c = pa.c + pb.c;
            w = pb.s[0];
            cc=0;               //此时进位为c
            for (i=0; i<pa.l; i++){
                ans.s[i] = (w*pa.s[i] + cc) % 10;
                cc= (w*pa.s[i] + cc) / 10;
            }
            if (cc!=0){
                ans.s[i++] = cc;
            }
            ans.l = i;
            return;                         //终止递归
        }

        //分治法的核心
        cp(pa,ah,ma,pa.l-ma);
        cp(pa,al,0,ma);
        cp(pb,bh,mb,pb.l-mb);
        cp(pb,bl,0,mb);

        mul(ah, bh, t1);           //分成4部分相乘
        mul(ah, bl, t2);
        mul(al, bh, t3);
        mul(al, bl, t4);

        add(t3,t4,ans);
        add(t2,ans,z);
        add(t1,z,ans);
    }

    public static void main(String[] args){
        Node ans=new Node();
        Node a = new Node();
        Node b = new Node();

        Scanner scanner=new Scanner(System.in);
        System.out.println("输入最大整数a：");
        sa=scanner.next();
        System.out.println("输入最大整数b：");
        sb=scanner.next();
        a.l=sa.length();                    //sa,sb以字符串进行处理
        b.l=sb.length();

        int z=0;
        for (int i=a.l-1;i>=0;i--)          //目的：倒向存储
            a.s[z++]=sa.charAt(i)-'0';      //它的作用就是减去0的ASCII值：48。
                                            // (char)数字-'0' --> (int)数字
                                            // (char)((int)数字 + 48) --> (char)数字
        a.c=0;
        z=0;
        for (int i=b.l-1; i>=0;i--)
            b.s[z++] = sb.charAt(i)-'0';
        b.c=0;

        mul(a,b,ans);

        System.out.println("最终结果为：");
        for (int i=ans.l-1; i>=0;i--)
            System.out.print(ans.s[i]);     //ans[]用来存储结果，倒向存储
        System.out.println();
    }
}
