package Algorithm.Chapter3._3_2;
/*3.2猜数游戏——二分搜索技术*/
import java.util.Scanner;
import java.util.Arrays;

public class Test3_2 {
    static int[] s;                     //存储元素的数组
    static int x,n;                     //x:要查找的元素，n元素个数

    /*初始化*/
    static void init(int N){            //N=n;
        s=new int[N];
    }

    static int BinarySearch(int n,int[] s,int x){
        int low=0;                      //low指向数组第一个元素
        int high=n-1;                   //high指向数组末尾元素
        while (low<=high){
            int middle=(low+high)/2;    //middle为查找范围的中间值
            if (x==s[middle])
                return middle;          //x等于查找范围的中间值，算法结束
            else if (x < s[middle])
                high = middle-1;        //x小于查找范围的中间元素，则从前半部分查找
            else
                low=middle+1;           //x大于查找范围的中间元素，则从后半部分查找
        }
        return -1;                      //不满足就返回-1
    }



    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        System.out.println("请输入数列中的元素个数n为：");
        n=scanner.nextInt();

        init(n);    //初始化数组

        while (n!=-1){
            System.out.println("请依次输入数列中的元素：");
            for (int i=0;i<n;i++){
                s[i]=scanner.nextInt();
            }

            Arrays.sort(s);                         //默认升序排序

            System.out.println("排序后的数组为：");
            for (int i=0;i<n;i++){
                System.out.print(s[i]+" ");
            }

            System.out.println("\n请输入要查找的元素：");
            x=scanner.nextInt();

            int ans=BinarySearch(n,s,x);              //二分查找
            if (ans==-1)
                System.out.println("该数列中没有要查找的元素！");
            else
                System.out.println("要查找的元素在第"+(ans+1)+"位");

            System.out.println("请输入数列中的元素个数n为：(输入-1程序结束)");
            n=scanner.nextInt();

        }
    }
}

