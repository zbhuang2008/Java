package Algorithm.Chapter4._4_6;
/*4.6快速计算——矩阵连乘*/
import java.util.Scanner;

public class Test4_6 {
    static int n;
    static int[] p;
    static int[][] m;
    static int[][] s;

    static void init(int N){                //N=n+1
        p=new int[N];                       //记录矩阵行列
        m=new int[N][N];                   //最优值数组
        s=new int[N][N];                   //最优决策数组
    }

    /*矩阵连乘求解函数*/
    public static void matrixChain(int[] p,int[][] m,int[][] s) {
        int i,j,r,k;
        for(r=2;r<=n;r++) {                            //2个矩阵连乘、3个矩阵连乘...n个矩阵连乘
            for(i=1;i<=n-r+1;i++) {                    //r个矩阵开始矩阵的下标
                j=i+r-1;                               //结束矩阵
                m[i][j]=m[i+1][j]+p[i-1]*p[i]*p[j];    //k=i时的乘法次数
                s[i][j]=i;                             //子问题的最优策略是i

                for(k=i+1;k<j;k++) {                   //对从i到j的所有策略求最优值
                    int temp=m[i][k]+m[k+1][j]+p[i-1]*p[k]*p[j];
                    if(temp<m[i][j]) {
                        m[i][j]=temp;
                        s[i][j]=k;
                    }
                }
            }
        }
    }

    /*最优解输出函数*/
    public static void print(int i,int j,int[][] s) {
        if(i==j) {
            System.out.print("A"+i);
            return;
        }

        System.out.print("(");
        print(i,s[i][j],s);
        print(s[i][j]+1,j,s);
        System.out.print(")");
    }

    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        System.out.println("请输入矩阵的个数n：");
        n=scanner.nextInt();

        init(n+1);              //因为从1~n开始，所以传入n+1,保险起见，可以尽量设大一点：n*10亦可

        System.out.println("请依次输入每个矩阵的行数和最后一个矩阵的列数：");
        for(int i=0;i<=n;i++)
            p[i]=scanner.nextInt();
        matrixChain(p,m,s);        //矩阵连乘求解函数
        print(1,n,s);
        System.out.println();
        System.out.println("最小计算量的值为："+m[1][n]);
    }
}
