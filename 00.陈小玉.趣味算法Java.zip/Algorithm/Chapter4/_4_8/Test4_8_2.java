package Algorithm.Chapter4._4_8;
/*4.8小石子游戏——石子合并:已经优化：枚举算法，把get_Min(),get_Max()抽取出来*/

import java.util.Scanner;

public class Test4_8_2 {
    static final double INF=Double.POSITIVE_INFINITY;           //无穷大
    static double[][] Min;                                      //路边玩法（直线型）最小花费
    static double[][] Max;                                      //路边玩法（直线型）最大花费
    static double[] sum;                                        //记录i...j之间的石子数之和
    static int[][] s;                                           //存储中间分隔点
    static int[] a;                                             //存储各堆的石子数的数组
    static double min_Circular;                                 //操场玩法（圆型）最小花费
    static double max_Circular;                                 //操场玩法（圆型）最大花费


    /*初始化*/
    static void init(int N){                                    //n=n*2
       Min=new double[N][N];
       Max=new double[N][N];
       sum=new double[N];
       s=new int[N][N];
       a=new int[N];
    }

    /*优化方法：把get_Min(),get_Max()单独写出来，由各游戏方法调用*/

    static void get_Min(int n){

        for(int v=2;v<=n;v++){                                  // 枚举合并的堆数规模
            for (int i=1;i<=n-v+1;i++){                         //枚举起始点i

                int j =i+v-1;                                   //枚举终点j
                double tmp = sum[j]-sum[i-1];                   //记录i...j之间的石子数之和
                int i1= s[i][j-1] > i ? s[i][j-1] : i;
                int j1= s[i+1][j] < j ? s[i+1][j] : j;
                Min[i][j]= Min[i][i1] + Min[i1+1][j];
                s[i][j]=i1;

                for (int k=i1+1; k<=j1; k++)                    //枚举中间分隔点
                    if (Min[i][k] + Min[k+1][j] < Min[i][j]){
                        Min[i][j] = Min[i][k] + Min[k+1][j];
                        s[i][j]=k;                              //别漏了这个
                    }

                Min[i][j]+=tmp;

            }//第2个for
        }//for
    }

    static void get_Max(int n){
        for (int v=2; v<=n;v++){                                // 枚举合并的堆数规模
            for (int i=1;i<=n-v+1;i++){                         //枚举起始点i

                int j =i+v-1;                                   //枚举终点j
                Max[i][j] = -1;                                 //初始化为-1
                double tmp = sum[j]-sum[i-1];                   //记录i...j之间的石子数之和
                if (Max[i+1][j] > Max[i][j-1])
                    Max[i][j] = Max[i+1][j] + tmp;
                else
                    Max[i][j] = Max[i][j-1] + tmp;
            }
        }
    }


    /*直线型玩法*/
    static void straight(int[] a,int n){
        //对角线初始化
        for (int i=1;i<=n;i++){
            Min[i][i]=0;
            Max[i][i]=0;
            s[i][i]=0;
        }

        //计算1~n的sum
        for (int i=1;i<=n;i++){
            sum[i]=sum[i-1]+a[i];
        }

        //调用get_Min(n),get_Max(n)
        get_Min(n);
        get_Max(n);
    }

    /*操场型玩法*/
    static void Circular(int[] a,int n){
        for (int i=1;i<=n-1;i++)
            a[n+i]=a[i];

        n=2*n-1;
        straight(a,n);                                          //同时调用了直线型玩法
        n=(n+1)/2;
        min_Circular=Min[1][n];
        max_Circular=Max[1][n];

        for (int i=2;i<=n;i++){
            if (Min[i][n+i-1] < min_Circular)
                min_Circular=Min[i][n+i-1];
            if (Max[i][n+i-1]>max_Circular)
                max_Circular=Max[i][n+i-1];
        }
    }

    public static void main(String[] args){
        int n;
        System.out.println("请输入石子的堆数：");
        Scanner scanner=new Scanner(System.in);
        n=scanner.nextInt();

        //初始化：尽量往最大设
        init(n*10);

        System.out.println("请依次输入各堆的石子数：");
        for (int i=1;i<=n;i++){
            a[i]=scanner.nextInt();
        }

        straight(a,n);
        System.out.println("路边玩法（直线型）最小花费为："+Min[1][n]);
        System.out.println("路边玩法（直线型）最大花费为："+Max[1][n]);

        Circular(a,n);
        System.out.println("操场玩法（圆型）最小花费为："+min_Circular);
        System.out.println("操场玩法（圆型）最大花费为："+max_Circular);
    }
}
