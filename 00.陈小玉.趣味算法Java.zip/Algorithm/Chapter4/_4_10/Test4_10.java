package Algorithm.Chapter4._4_10;
/*4.10快速定位——最优二叉搜索树: 未优化
* 注意区分：最优二叉树是哈夫曼树，跟最优二叉查找树不一样
* 如果在二叉树中查找元素不考虑概率及查找不成功的情况下，可以采用红黑树或者平衡二叉树来搜索，
* 这样可以在O(lgn)时间内完成。而现实生活中，查找的关键字是有一定的概率的，
* 就是说有的关键字可能经常被搜索，而有的很少被搜索，而且搜索的关键字可能不存在，
* 为此需要根据关键字出现的概率构建一个二叉树。比如中文输入法字库中各词条（单字、词组等）的先验概率，
* 针对用户习惯可以自动调整词频——所谓动态调频、高频先现原则，以减少用户翻查次数，使得经常用的词汇被放置在前面，这样就能有效地加快查找速度。
* 这就是最优二叉查找树所要解决的问题。
* */

import java.text.DecimalFormat;
import java.util.Scanner;

public class Test4_10 {
    static double[][] c;
    static double[][] w;
    static double[] p;
    static double[] q;
    static int[][] s;
    static int n,i,j,k;

    /*初始化*/
    static void init(int N){
        c=new double[N][N];
        w=new double[N][N];
        p=new double[N];
        q=new double[N];
        s=new int[N][N];
    }

    /*构建最优二叉搜索树*/
    static void Optimal_BST(){
        for (i=1 ; i<=n+1 ; i++){
            c[i][i-1]=0;
            w[i][i-1]=q[i-1];
        }
        for (int t=1; t<=n;t++)                 //t为关键字的规模
            for (i=1; i<=n-t+1;i++){            //从下标i开始的关键字到下标为j的关键字(注意条件别写错)

                j=i+t-1;
                w[i][j]=w[i][j-1]+p[j]+q[j];
                c[i][j]=c[i][i-1]+c[i+1][j];    //初始化
                s[i][j]=i;                      //初始化

                for (k=i+1;k<=j;k++){           //选取i+1到j之间的某个下标的关键字作为从i到j的根，
                                                // 如果组成的树的期望值当前最小，则k为从i到j的根节点
                    double temp = c[i][k-1]+c[k+1][j];
                    if (temp < c[i][j]){
                        c[i][j]=temp;
                        s[i][j]=k;              //k即为从下标i到j的根节点
                    }
                }
                c[i][j]+=w[i][j];

            }//for
    }

    /*遍历并打印最优二叉查找树*/
    static void Construct_Optimal_BST(int i,int j,boolean flag){
        if (flag==false){
            System.out.println("S"+s[i][j]+" 是根");
            flag=true;
        }
        int k = s[i][j];

        //如果左子树是叶子
        if (k-1<i){
            System.out.println("e"+(k-1)+" is the left child of S"+k);
        }
        //如果左子树不是叶子
        else{
            System.out.println("S"+s[i][k-1]+" is the left child of S"+k);
            Construct_Optimal_BST(i,k-1,true);  //往左递归
        }

        //如果右子树是叶子
        if (k>=j){
            System.out.println("e"+k+" is the right child of S"+k);
        }
        //如果右子树不是叶子
        else{
            System.out.println("S"+s[k+1][j]+" is the right child of S"+k);
            Construct_Optimal_BST(k+1,j,true);  //往右递归
        }
    }

    public static void main(String[] args){
        Scanner scanner=new Scanner(System.in);
        System.out.println("请输入关键字的个数n: ");
        n=scanner.nextInt();

        /*初始化：n尽量大,虚结点搜索概率数量比n大*/
        init(n*2);

        System.out.println("请输入每个关键字的搜索概率：");
        for (int i=1;i<=n;i++)
            p[i]=scanner.nextDouble();

        System.out.println("请输入每个虚结点的搜索概率：");
        for (int i=0;i<=n;i++)              //注意是从0开始存储的,即从根结点开始
            q[i]=scanner.nextDouble();

        //构建最优二叉查找树
        Optimal_BST();

        DecimalFormat df=new DecimalFormat("0.00");         //控制2位小数
        System.out.println("最小的搜索成本为："+df.format(c[1][n]));
        System.out.println("最优二叉搜索树为：");
        Construct_Optimal_BST(1,n,false);
    }
}
