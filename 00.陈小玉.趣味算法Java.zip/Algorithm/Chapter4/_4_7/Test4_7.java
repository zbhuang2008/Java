package Algorithm.Chapter4._4_7;
/*4.7切呀切披萨——最优三角剖分*/

import java.util.Scanner;

public class Test4_7 {
    static int[][] s;                   //划分点数组
    static double[][] m;                //最优值数组
    static double[][] g;                //权值数组
    static int n;                       //顶点个数

    /*初始化*/
    static void init(int N){            //n=n+1,下标从1~n算起，故+1
        s=new int[N][N];
        m=new double[N][N];
        g=new double[N][N];
    }

    static void Convexpolygontriangulation(){
        //对角线元素设为0
        for (int i=1;i<=n;i++){          //此n正是数量n
            m[i][i]=0;
            s[i][i]=0;
        }
        for (int d=2;d<=n;d++)
            for (int i=1;i<=n-d+1;i++){
            int j =i+d-1;
            m[i][j] = m[i+1][j] + g[i-1][i] + g[i][j] + g[i-1][j];
            s[i][j]=i;

            for (int k = i+1; k<j; k++){
                double temp = m[i][k] + m[k+1][j] + g[i-1][k] + g[k][j] + g[i-1][j];
                if (m[i][j] > temp){
                    m[i][j] = temp;     //更新最优值
                    s[i][j] = k;        //记录划分点
                }
            }
        }
    }

    /*输出所有的弦*/
    static void print(int i,int j){
        if (i==j) return;
        if (s[i][j] >i)
            System.out.println("{v"+(i-1)+",v"+s[i][j]+"}");
        if (j>s[i][j]+1)
            System.out.println("{v"+s[i][j]+",v"+j+"}");
        print(i,s[i][j]);
        print(s[i][j]+1,j);
    }

    public static void main(String[] args){
        Scanner scanner=new Scanner(System.in);
        System.out.println("请输入顶点的个数n：");
        n=scanner.nextInt();
        init(n+1);         //因为从1~n开始，所以传入n+1,保险起见，可以尽量设大一点：n*10亦可
        n--;

        System.out.println("请依次输入各顶点的连接权值：");
        for (int i=0;i<=n;i++){
            for (int j=0;j<=n;j++){
                g[i][j]=scanner.nextDouble();
            }
        }

        //进行划分求最优值
        Convexpolygontriangulation();
        System.out.println(m[1][n]);
        print(1,n);                                 //打印路径
    }
}
