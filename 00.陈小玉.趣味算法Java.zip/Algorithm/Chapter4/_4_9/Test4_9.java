package Algorithm.Chapter4._4_9;
/*4.9大卖场购物车 1——0-1 背包问题*/
import java.util.Scanner;

public class Test4_9 {
    static int[] w;                                 //存放所有物品的重量
    static int[] v;                                 //存放所有物品的价值
    static int[][] c;                               //表示前i个物品放入容量为j的购物车获得的最大价值
    static int[] x;                                 //表示第i个物品是否放入购物车
    static int n,W;                                //n表示n个物品，W表示购物车容量


    static void init(int W){
        w=new int[W];
        v=new int[W];
        c=new int[W][W*W];
        x=new int[W];
    }

    static void knapsack(int n){
        //计算c[i][j]
        for(int i=1;i<=n;i++) {                                     //控制物品个数
            for(int j=1;j<=W;j++) {                                 //控制容量大小
                if(w[i]>j)                                          //物品重量大于购物车容量，则不放入第i个物品
                    c[i][j]=c[i-1][j];
                else
                    c[i][j]=Math.max(c[i-1][j],c[i-1][j-w[i]]+v[i]);//比较放入此物品与不放入此物品哪个价值更大
            }
        }
        System.out.println("装入购物车的最大价值为："+c[n][W]);

        //逆向构造最优解
        int j=W;
        for(int i=n;i>0;i--) {                                      //从最后一个物品开始判断
            if(c[i][j]>c[i-1][j]) {                                 //说明第i个物品放入购物车
                x[i]=1;
                j-=w[i];
            }
            else
                x[i]=0;                                             //说明第i个物品没有放入购物车
        }
        System.out.println("装入购物车的物品为：");
        for(int i=1;i<=n;i++) {
            if(x[i]==1)
                System.out.print(i+"  ");
        }
    }


    public static void main(String[] args) {

        Scanner scanner=new Scanner(System.in);
        System.out.println("请输入物品的个数n：");
        n=scanner.nextInt();
        System.out.println("请输入购物车的容量W：");
        W=scanner.nextInt();

        init(W);          //初始化购物车

        System.out.println("请依次输入每个物品的重量w和价值v，用空格分开：");
        for(int i=1;i<=n;i++) {
            w[i]=scanner.nextInt();
            v[i]=scanner.nextInt();
        }

        knapsack(n);

    }
}
