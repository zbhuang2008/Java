package Algorithm.Chapter5._5_4;
/*5.4地图调色板——地图着色*/
import java.util.Scanner;
 
public class Test5_4 {
	static int[] x;                                     			//解分量
	static int[][] map;                             				//图的邻接矩阵
	static int sum;                                                 //记录解的个数
	static int n,m,edge;                                            //n代表节点数，m代表颜色数，edge代表图的边数

	static void init(int N){										//N=n+1;
		x=new int[N];
		map=new int[N][N];
	}

	/*搜索函数*/
	public static void backTrack(int t) {
		if(t>n) {                                                    //到达叶子结点，找到一个可行解
			sum++;                                                   //可行解个数加1
			System.out.print("第"+sum+"种方案：");
			for(int i=1;i<=n;i++)                                    //输出该着色方案
				System.out.print(x[i]+" ");
			System.out.println();
		}
		else {
			for(int i=1;i<=m;i++) {                                  //每个结点尝试m种颜色
				x[t]=i;
				if(OK(t))                                            //判断是否满足约束条件，若不满足换下一个色号尝试
					backTrack(t+1);                                  //若满足则进入下一层继续搜索
			}
		}
	}
	
    /*约束条件*/
	public static boolean OK(int t) {
		for(int j=1;j<t;j++) {                                       //依次判断前t-1个结点
			if(map[t][j]==1) {                                       //判断t和j是否相邻
				if(x[j]==x[t])                                       //判断着色是否相同
					return false;                                    //有相同着色则返回false
			}
		}
		return true;
	}

    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        System.out.println("输入节点数：");
        n=scanner.nextInt();

        init(n+1);												//初始化，下标范围[1,n],故n+1

        System.out.println("输入颜色数：");
        m=scanner.nextInt();
        System.out.println("输入无向图的邻接矩阵：");
        System.out.println("请输入边数：");
        edge=scanner.nextInt();

        int u,v;
        System.out.println("请依次输入有边相连的两个结点u和v，用空格分开：");
        for(int i=1;i<=edge;i++) {
            u=scanner.nextInt();
            v=scanner.nextInt();
            map[u][v]=map[v][u]=1;									//无向图双向赋权值，默认为1
        }

        backTrack(1);                                            //从第1层开始搜索
    }
	
}
