package Algorithm.Chapter5._5_2;
/*5.2.7大卖场购物车2 ——0-1 背包问题:已经优化
* 注意：请对比：6_2_7的代码：结构差不多，只是添加了Goods对象，搜索方法换成bfs()
* */
import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

public class Test5_2_2 {
	static int[] bestx;                             //当前最优解
	static Object[] S;								//用来按单位重量价值排序的数组，记录排序后的商品
	static int[] w;                                 //w[i]表示第i个物品的重量
	static int[] v;                                 //v[i]表示第i个物品的价值
	static int[] x;                                 //表示第i个物品是否放入购物车
	static int n,W;                              	//n表示n个物品，W表示购物车的容量
	static double bestp;							//当前最优值，默认为0
	static int cw,cp;								//cw:当前放入购物车的物品重量 ; cp:当前放入购物车的物品价值,默认为0

	/*初始化购物车*/
	static void init(int N,int W){
		bestx=new int[W];
		w=new int[W];
		v=new int[W];
		x=new int[W];
		S=new Object[N];

		for (int i=0;i<N;i++){
			S[i]=new Object();
		}
	}

	static class Object{
		int id;
		double d;
	}

	/*自定义比较规则：按照物品单位重量价值由大到小排序：降序排序*/
	static class cmp<A extends Test5_2_2.Object> implements Comparator<A>{
		@Override
		public int compare(A a1, A a2) {
			if (a1.d>a2.d)					//满足降序，按降序排序，return -1;
				return -1;
			else if (a1.d<a2.d)
				return 1;
			else
				return 0;
		}
	}

	/*计算上界，可容纳剩余物品的最大价值*/
	static int bound(int i) {
		int cleft=W-cw;                                        //购物车剩余容量
		int brp=0;
		while(i<=n && w[i]<cleft) {                              //加快剪枝速度
			cleft-=w[i];
			brp+=v[i];
			i++;
		}
		if(i<n)                                                //采用切割的方式装满背包，求解时不允许切割
			brp+=v[i]/w[i]*cleft;
		return cp+brp;
	}


	static void knapsack(int n,int W) {
		double sumw=0;                                              //用来统计所有物品的总重量
		double sumv=0;                                             //用来统计所有物品的总价值
		int[] a=new int[n+1];                    				  //辅助数组a[]
		int[] b=new int[n+1];									  //辅助数组b[]

		//从下标1开始，标记每一个商品的 id和 [价值重量比]，下面再根据[价值重量比]对购物车的商品排序
		for(int i=1;i<=n;i++) {
			S[i-1].id=i;
			S[i-1].d=v[i]/w[i];									//[价值重量比]
			sumw+=w[i];
			sumv+=v[i];
		}

		if(sumw<=W) {                                            //所有物品可放入购物车
			bestp=sumv;
			System.out.println("放入购物车的物品最大价值为："+bestp);
			System.out.println("所有的物品均放入购物车。");
			return;
		}

        Arrays.sort(S,new cmp());       						//按[价值重量比]从大到小进行排序

		for(int i=1;i<=n;i++) {
			a[i]=w[S[i-1].id];                                   //排序后的重量
			b[i]=v[S[i-1].id];                                   //排序后的价值
		}
		for(int i=1;i<=n;i++) {									//把排序好的内容复制给原来的w,v数组
			w[i]=a[i];
			v[i]=b[i];
		}

		backTrack(1);                                            //从第一层开始搜索

		System.out.println("放入购物车的物品最大价值为："+bestp);
		System.out.print("放入购物车的物品序号为：");
		for(int i=1;i<=n;i++) {										//输出最优解
			if(bestx[i]==1)
				System.out.print(S[i-1].id+" ");
		}
	}
	
	/*用于搜索空间数，t表示当前扩展结点在第t层*/
	static void backTrack(int t) {
		if(t>n) {                                                //已经到达叶子结点，记录最优值最优解
			for(int j=1;j<=n;j++) {                              //保存最优解
				bestx[j]=x[j];
			}
			bestp=cp;
			return;                                              //保存当前最优值
		}
		
		if(cw+w[t]<=W) {                                         //如果满足约束条件则搜索左子树即放入物品
			x[t]=1;                                              //放入购物车
			cw+=w[t];                                            //购物车当前的重量增加
			cp+=v[t];                                            //购物车当前的价值增加
			backTrack(t+1);                                   //递推深度优先搜索第t+1层
			
			cw-=w[t];                                            //上向回归时要把增加的值减去
			cp-=v[t];
		}
		
		if(bound(t+1)>bestp) {                                   //如果满足限界条件则搜索右子树
			x[t]=0;                                                 //不放入物品，当前放入物品重量价值均不改变
			backTrack(t+1);                                      //深度优先搜索第t+1层
		}
	}
	

    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        System.out.println("请输入物品的个数n：");
        n=scanner.nextInt();
        System.out.println("请输入购物车的容量W：");
        W=scanner.nextInt();

        init(n,W);				//初始化购物车

        System.out.println("请依次输入每个物品的重量w和价值v，用空格分开：");
        for(int i=1;i<=n;i++) {
            w[i]=scanner.nextInt();
            v[i]=scanner.nextInt();
        }

        knapsack(n,W);                                           //背包问题求解
        scanner.close();
    }

}
