package Algorithm.Chapter5._5_7;
/*5.7奇妙之旅 1——旅行商问题：已经优化*/
import java.util.Arrays;
import java.util.Scanner;


public class Test5_7_2 {
    static final double INF=Double.POSITIVE_INFINITY;
    static double[][] g;                //邻接矩阵作为地图，存路径权值
    static int[][] bestx;               //记录当前最优路径长度的结点
    static double[][]dp;                //dp[i][j] 表示第i个状态，到达第j个城市的最短路径
    static double bestl;                //bestl:当前最短路径长度
    static int n,m;                     //n：城市个数，m:边数
    static int sx,S;


    /*初始化*/
    static void init(int N,int M){       //N=n+1,M=m*10
        g=new double[N][N];
        bestx=new int[M][N];            //默认为0
        dp=new double[M][N];

        bestl=INF;
        for (int i=0;i<N;i++){
            for (int j=0;j<N;j++){
                g[i][j]=INF;
            }
        }

        for (int i=0;i<M;i++){
            for (int j=0;j<N;j++){
                dp[i][j]=INF;
            }
        }

    }

    static void Traveling(){
        dp[1][0]=0;
        S=1<<n;             //S=2^n

        for (int i=0; i<S;i++){
            for (int j=0;j<n;j++){

                if((i & (1<<j))==0) continue;
                for (int k=0 ; k<n; k++){

                    if ((i & (1<<k))!=0) continue;
                    if(dp[i|(1<<k)][k] > dp[i][j] + g[j][k]){

                        dp[i|(1<<k)][k] = dp[i][j] + g[j][k];
                        bestx[i|(1<<k)][k] = j ;
                    }
                }
            }//中for
        }//大for

        //查找最短路径长度
        for (int i=0; i<n; i++){
            if (bestl > dp[S-1][i] + g[i][0]){
                bestl = dp[S-1][i] + g[i][0];
                sx=i;
            }
        }
    }

    /*打印路径*/
    static void print(int S,double value){
        if (S==0) return;
        for (int i=0;i<n;i++){
            if (dp[S][i] == value){
                print(S^(1<<i),value - g[i][bestx[S][i]]);
                System.out.print((i+1)+"--->");
                break;
            }
        }
    }

    public static void main(String[] args){
        int u,v;                              //u,v代表城市
        double w;                            //w代表u和v城市之间路的长度
        Scanner scanner=new Scanner(System.in);

        System.out.println("请输入景点数n(结点数)：");
        n=scanner.nextInt();


        System.out.println("请输入景点之间的连线数(边数)：");
        m=scanner.nextInt();

        init(n+1,m*10);             //初始化：图尽量设大:n+1只是为了以备超出范围的情况，边数设大一点，避免超出范围

        System.out.println("请依次输入两个景点u和v之间的距离w，格式：景点u 景点v 距离w：");
        for (int i=0;i<m;i++){              //注意，这种是从0位开始赋值，所以对应的结点值-1，对应下标插入
            u=scanner.nextInt();
            v=scanner.nextInt();
            w=scanner.nextDouble();
            g[u-1][v-1]=g[v-1][u-1]=w;      //无向图，双向赋值
        }

        Traveling();
        System.out.print("最短路径：");
        print(S-1,bestl-g[sx][0]);
        System.out.println(1);                      //起点是1
        System.out.print("最短路径长度："+bestl+"\n");
    }
}
