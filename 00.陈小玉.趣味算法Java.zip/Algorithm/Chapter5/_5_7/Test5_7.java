package Algorithm.Chapter5._5_7;
/*5.7奇妙之旅 1——旅行商问题：未优化*/
import java.util.Scanner;

public class Test5_7 {
    static final double INF=Double.POSITIVE_INFINITY;
    static double[][] g;                //邻接矩阵作为地图，存路径权值
    static int[] x;                     //记录当前路径
    static int[] bestx;                 //记录当前最优路径长度的结点
    static double cl,bestl;             //cl:当前路径长度，bestl:当前最短路径长度
    static int n,m;                     //n：城市个数，m:边数

    /*初始化*/
    static void init(int N){            //N=n+1
        g=new double[N][N];
        x=new int[N];
        bestx=new int[N];               //默认初始化为0

        bestl=INF;
        cl=0;

        for(int i=0;i<N;i++){
                x[i]=i;                 //结点值对应索引值
            for (int j=0;j<N;j++)
                g[i][j]=INF;            //表示路径不可达
        }
    }

    static void Traveling(int t){
        //到达叶子结点
        if (t>n){                                             //推销货物的最后一个城市与住地城市有边相连并且路径长度比当前最优值小
            if(g[x[n]][1]!=INF && (cl+g[x[n]][1]<bestl)){    //说明找到了一条更好的路径，记录相关信息
                for(int j=1;j<=n;j++)
                    bestx[j]=x[j];
                bestl=cl+g[x[n]][1];
            }
        }
        //没有到达叶子结点
        else{
            for (int j=t; j<=n; j++){                                      //搜索扩展结点的所有分支
                if (g[x[t-1]][x[j]]!=INF && (cl+g[x[t-1]][x[j]]<bestl)){  //如果第t-1个城市与第t个城市有边相连并且有可能得到更短的路线
                    //保存第t个要去的城市编号到x[t]中，进入到第t+1层
                    swap(t,j);                                           //交换两个元素的值
                    cl=cl+g[x[t-1]][x[t]];
                    Traveling(t+1);                                  //从第t+1层的扩展结点继续搜索

                    cl=cl-g[x[t-1]][x[t]];                              //第t+1层搜索完毕，回溯到第t层
                    swap(t,j);
                }
            }
        }
    }

    /*交换函数*/
    static void swap(int t,int j){
        int temp=x[t];
        x[t]=x[j];
        x[j]=temp;
    }


    /*打印路径*/
    static void print(){
        System.out.println("最短路径：");
        for (int i=1; i<= n; i++){
            System.out.print(bestx[i]+"--->");
        }
        System.out.println("1");
        System.out.print(" 最短路径长度："+bestl);
    }

    public static void main(String[] args){
        int u,v;                              //u,v代表城市
        double w;                            //w代表u和v城市之间路的长度
        Scanner scanner=new Scanner(System.in);

        System.out.println("请输入景点数n(结点数)：");
        n=scanner.nextInt();

        //初始化:从1~n，所以长度n+1
        init(n+1);


        System.out.println("请输入景点之间的连线数(边数)：");
        m=scanner.nextInt();
        System.out.println("请依次输入两个景点u和v之间的距离w，格式：景点u 景点v 距离w：");
        for (int i=1;i<=m;i++){
            u=scanner.nextInt();
            v=scanner.nextInt();
            w=scanner.nextDouble();
            g[u][v]=g[v][u]=w;      //无向图，双向赋值
        }

        Traveling(2);
        print();
    }
}
