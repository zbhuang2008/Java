package Algorithm.Chapter5._5_3;
/*5.3部落护卫队——最大团*/
import java.util.Scanner;

public class Test5_3 {
    static int n,m;                                         //n为图中结点数，m为图中边数
    static int[][] a;                                       //图用邻接矩阵表示
    static int[] x;                                         //是否将第i个结点加入团中
    static int[] bestx;                                     //记录最优解
    static int bestn,cn;                                   //记录最优值，当前已放入团中的结点数量

    static void init(int N){                              //N=n
        a=new int[N][N];
        x=new int[N];
        bestx=new int[N];
    }

    public static void backTrack(int t) {
        if(t>n) {                                                          //表示到达叶子结点，得到一个可行解
            for(int i=1;i<=n;i++)                                          //记录最优值和最优解
                bestx[i]=x[i];
            bestn=cn;
            return;
        }
        if(place(t)) {                                                     //判断是否满足约束条件，即t是否可以加入团中
            x[t]=1;
            cn++;                                                          //当前加入团中的结点+1
            backTrack(t+1);                                                //深度搜索t+1层
            cn--;                                                          //向上回溯
        }
        if(cn+n-t>bestn) {                                                 //判断是否满足限界条件，搜索右子树
            x[t]=0;
            backTrack(t+1);
        }
    }

    /*判断结点t是否可以加入团中，即t与团中的所有结点是否都相连*/
    public static boolean place(int t) {
        boolean ok=true;
        for(int j=1;j<t;j++) {
            if(x[j]==1 && a[t][j]==0) {                                   //表示结点j被选中，且t和j没有边相连
                ok=false;
                break;
            }
        }
        return ok;
    }

    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        System.out.println("请输入部落的人数n（结点数）：");
        n=scanner.nextInt();

        init(n+1);              //初始化，下标范围[1,n],故n+1

        System.out.println("请输入人与人的友好关系数（边数）：");
        m=scanner.nextInt();

        int u,v;
        System.out.println("请依次输入有友好关系的两个人（有边相连的两个结点u和v）用空格分开：");
        for(int i=1;i<=m;i++) {
            u=scanner.nextInt();
            v=scanner.nextInt();
            a[u][v]=a[v][u]=1;                                             //两结点之间有边
        }
        bestn=0;
        cn=0;
        backTrack(1);                                                      //从第1层开始调用回溯法搜索
        System.out.println("国王护卫队的最大人数为："+bestn);
        System.out.print("国王护卫队的成员为：");
        for(int i=1;i<=n;i++) {
            if(bestx[i]==1)
                System.out.print(i+" ");
        }
        System.out.println();
        scanner.close();
    }
}