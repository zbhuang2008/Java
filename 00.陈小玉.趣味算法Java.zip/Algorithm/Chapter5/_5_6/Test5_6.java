package Algorithm.Chapter5._5_6;
/*5.6机器零件加工——最优加工顺序：未优化*/
import java.util.Arrays;
import java.util.Scanner;

public class Test5_6 {
    static final Integer INF=Integer.MAX_VALUE;
    static int[] x;
    static int[] bestx;
    static Node[] T;
    static int f1,f2;       //f1表示当前第一台机器上加工的完成时间,f2表示当前第二台机器上加工的完成时间
    static int bestf;       //用来接收最新的最优值f2
    static int n;

    static void init(int N){    //N=n+1
        x=new int[N];
        bestx=new int[N];
        T=new Node[N];

        for (int i=0;i<N;i++){
            T[i]=new Node();
        }
    }

    static class Node{
        int x,y;            //机器零件在第一台机器上的加工时间x和第二台机器上的加工时间y
    }

    /*深入搜索*/
    static void Backtrack(int t){
        if (t>n){                       //到达叶子结点
            for (int i=1;i<=n;i++)      //记录最优排列
                bestx[i]=x[i];
            bestf=f2;                   //更新最优值
            return;                     //递归结束
        }
        for (int i=t; i<=n;i++){
            f1+=T[x[i]].x;
            int temp=f2;
            f2=Math.max(f1,f2)+T[x[i]].y;
            if (f2<bestf){              //限界条件
                swap(t,i);              //交换
                Backtrack(t+1);      //继续深入搜索
                swap(t,i);              //复位，反操作
            }
            f1-=T[x[i]].x;
            f2=temp;
        }
    }

    /*交换函数*/
    static void swap(int t,int i){
        int temp=x[t];
        x[t]=x[i];
        x[i]=temp;
    }

    public static void main(String[] args){
        Scanner scanner=new Scanner(System.in);
        System.out.println("请输入机器零件的个数n:");
        n=scanner.nextInt();

        init(n+1);      //初始化，下标范围[1,n],故+1

        System.out.println("请依次输入每个机器零件在第一台机器上的加工时间x和第二台机器上的加工时间y：");
        for (int i=1;i<=n;i++){
            T[i].x=scanner.nextInt();
            T[i].y=scanner.nextInt();
            x[i]=i;
        }
        bestf=INF;
        f1=f2=0;
        Arrays.fill(bestx,0);

        //深搜排列树
        Backtrack(1);
        System.out.println("最优的机器零件加工顺序为：");
        for (int i=1;i<=n;i++)
            System.out.print(bestx[i]+" ");

        System.out.println("\n最优的机器零件加工的时间为："+bestf);
    }

}
