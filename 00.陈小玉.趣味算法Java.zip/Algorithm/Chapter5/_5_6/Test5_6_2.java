package Algorithm.Chapter5._5_6;
/*5.6机器零件加工——最优加工顺序：已经优化：贝尔曼规则*/

import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

public class Test5_6_2 {
    static final double INF=Double.POSITIVE_INFINITY;
    static Node[] T;
    static int f1,f2;       //f1表示当前第一台机器上加工的完成时间,f2表示当前第二台机器上加工的完成时间
    static int n;

    static void init(int N){    //N=n+1
        T=new Node[N];
        for (int i=0;i<N;i++)
            T[i]=new Node();
    }

    static class Node{
        int id;
        int x,y;
    }

    /*使用贝尔曼规则排序*/
    static class cmp<A extends Node> implements Comparator<A>{
        @Override
        public int compare(A a, A b) {
            int minxy=Math.min(b.x,a.y);
            int minyx=Math.min(b.y,a.x);
            if (minxy>=minyx)   //满足规则的，交换顺序
                return -1;
            else
                return 1;       //不满足规则的，不交换顺序，return 0;也可以
        }
    }

    public static void main(String[] args){
        Scanner scanner=new Scanner(System.in);
        System.out.println("请输入机器零件的个数n:");
        n=scanner.nextInt();

        init(n+1);      //初始化，下标范围[1,n],故+1

        System.out.println("请依次输入每个机器零件在第一台机器上的加工时间x和第二台机器上的加工时间y：");
        for (int i=1;i<=n;i++){
            T[i].x=scanner.nextInt();
            T[i].y=scanner.nextInt();
            T[i].id=i+1;
        }

        //按贝尔曼规则排序
        Arrays.sort(T,new cmp());
        for (int i=0;i<n;i++){
            f1+=T[i].x;
            f2=Math.max(f1,f2)+T[i].y;
        }

        System.out.println("最优的机器零件加工顺序为：");
        for (int i=0;i<n;i++)
            System.out.print(T[i].id+" ");
        System.out.println("\n最优的机器零件加工的时间为："+f2);
    }
}
