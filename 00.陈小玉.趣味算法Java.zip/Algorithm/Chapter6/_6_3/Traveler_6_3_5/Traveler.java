package Algorithm.Chapter6._6_3.Traveler_6_3_5;
import java.util.Scanner;
//6.3.5旅行者-未优化
public class Traveler {
    static final double INF = Double.POSITIVE_INFINITY;  //设置路径权值无穷大
    static double[][] g;                                //邻接矩阵,用来构造加权无向图
    static int[] bestx;                                 //记录当前最优路径
    static double bestl;                                //记录当前最优路径长度
    static int n,m;                                     //(景点)结点个数n,边数m

        /*初始化加权无向图,因为结点从[1,n]，忽略行列为0部位，所以设置时n+1*/
    public static void init(int N){
        g = new double[N][N];
        bestx=new int[N];
        bestl=INF;

        for (int i=0;i<N;i++){
            bestx[i]=0;
        }
        for (int i=1;i<=n;i++)              //下标范围[1,n]
            for (int j=i;j<=n;j++)
                g[i][j]=g[j][i]=INF;        //对角线设置为最大值，表示结点自己对自己，路径不可达

    }


    /*定义结点，记录当前结点结信息*/
    public static class Node implements Comparable<Node>{
        double cl;
        int id;
        int[] x;
        Node(double cl,int id){
            x=new int[n+1];
            this.cl=cl;
            this.id=id;
        }

        //使用最小优先队列，规定对比cl,cl值小的越优先
        @Override
        public int compareTo(Node node) {
            if (this.cl<node.cl){
                return 1;
            }else if(this.cl>node.cl){
                return -1;
            }else{
                return 0;
            }
        }
    }


    /*广度优先遍历*/
    public static double Travelingbfs(){
        int t;                                              //当前处理景点序号t

        Node livenode,newnode;                              //设置两个指针，一个指向当前结点，一个指向新结点

        //创建最小优先队列：比较的内容是走过的路径长度cl,cl值越小越优先
        MinPriorityQueue<Node> q = new MinPriorityQueue<>(n+1);

        newnode = new Node(0,2);                     //创建根结点，根结点长度为0
        for(int i=1;i<=n;i++){                              //忽略0，从下标1开始初始化解向量
            newnode.x[i]=i;
        }
        q.insert(newnode);                                  //根结点加入优先队列
        while (!q.isEmpty()){
            livenode=q.delMin();                            //取出队头最小元素作为当前扩展结点livenode
            t = livenode.id;                                //当前处理的结点序号

            //搜到倒数第2个结点时，不需要往下搜索
            if (t == n) {                                    //例如当前找到一个路径（1243），到达4号结点时，立即判断g[4][3]和g[3][1]是否有边相连，
                                                            // 如果有边则判断当前路径长度cl+g[4][3]+g[3][1]<bestl，满足则更新最优值和最优解
                //找到一条更短的路径，记录相关信息
                if (g[livenode.x[n - 1]][livenode.x[n]] != INF && g[livenode.x[n]][1] != INF)
                    if (livenode.cl + g[livenode.x[n - 1]][livenode.x[n]] + g[livenode.x[n]][1] < bestl) {
                        bestl = livenode.cl + g[livenode.x[n - 1]][livenode.x[n]] + g[livenode.x[n]][1];
                    } //小if结束

                //记录当前最优解向量
                for (int i = 1; i <= n; i++) {
                    bestx[i] = livenode.x[i];
                }
                continue;

                } //if(t==n)结束

                //判断当前结点是否满足限界条件，不满足则扩展
                if (livenode.cl >= bestl){
                    continue;
                }
                //否则，扩展
                //没有到达叶子结点
                for (int j=t;j<=n;j++){
                    if(g[livenode.x[t-1]][livenode.x[j]]!=INF){           //如果x[t-1]景点与x[j]景点有边相连
                        double cl=livenode.cl+g[livenode.x[t-1]][livenode.x[j]];
                        if (cl<bestl){                                   //有可能得到更短的路径
                            newnode=new Node(cl,t+1);
                            for (int i=1;i<=n;i++){
                                newnode.x[i]=livenode.x[i];             //复制以前的解向量
                            }
                            newnode=swap(newnode,t,j);                  //交换x[t]和x[j]
                            q.insert(newnode);                           //新结点入队
                        } //小if结束

                    }//大if结束
                } //for结束
        } //while结束

        return bestl;
    }

    /*交换x[t]和x[j]*/
    static Node swap(Node newnode, int t, int j) {
        int tmp = newnode.x[t];
        newnode.x[t]=newnode.x[j];
        newnode.x[j]=tmp;
        return newnode;
    }



    /*打印路径*/
    public static void print_shortpath(){
        System.out.println("最短路径：");
        for (int i=1;i<=n;i++){
            System.out.print(bestx[i]+"--->");
        }
        System.out.println("1");
        System.out.println("最短路径长度："+bestl);
    }


    public static void main(String[] args){
        int u, v, w;//u,v代表城市，w代表u和v城市之间路的长度
        Scanner scanner = new Scanner(System.in);

        System.out.println("请输入景点树n(结点数)：");
        n = scanner.nextInt();

        //初始化邻接矩阵和记录最短路径的数组
        init(n+1);

        System.out.println("请输入景点之间的连线数(边数)：");
        m = scanner.nextInt();

        System.out.println("请依次输入两个景点u和v之间的距离w，格式：景点u 景点v 距离w：");
        //每次读取一行，按空格分离
        for (int i=1;i<=m;i++){
            u=scanner.nextInt();
            v=scanner.nextInt();
            w=scanner.nextInt();

            //无向图是双向的,给无向图赋权值
            g[u][v]=g[v][u]=w;
        }

          System.out.println();

          //广度遍历，求起点到每个结点的最短路径
          Travelingbfs();

          //打印：从1出发所经过的最短路径的结点
          print_shortpath();
    }

}
