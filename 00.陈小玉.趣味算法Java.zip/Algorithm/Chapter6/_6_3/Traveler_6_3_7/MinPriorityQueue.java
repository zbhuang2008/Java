package Algorithm.Chapter6._6_3.Traveler_6_3_7;
//最小优先队列

import java.util.LinkedList;
import java.util.Queue;

//T类对象要调用compareTo(T t)方法，故向上继承Comparable类，
//compareTo(T t)里面的参数也是同类，所以Comparable类声明其下方法参数的类型。
public class MinPriorityQueue<T extends Comparable<T>> {
    private T[] items;
    private Queue<T> container;
    private int N;

    public MinPriorityQueue(int capability){
        items = (T[]) new Comparable[capability+1]; //创建一个数组，承接传进来的数组
        container = new LinkedList<>();//创建一个队列，接收删除的根节点。
        N=0;
    }


    public int size(){
        return  N;
    }

    public boolean isEmpty(){
        return N==0;
    }

    //主要的方法有void insert(T t)和 T delMin()
    public void insert(T t){
        items[++N] = t;
        swim(N);//N正好是新插入的结点的索引，对其上浮，使堆序恢复
    }

    //要保持的堆序是：父结点<子结点
    private void swim(int n) {
        while(n>1){ //当n还不是根节点时就上浮
            if(items[n].compareTo(items[n/2])<0){
                exch(n,n/2);
            }
            n = n/2; //交换完父子结点，n指向父结点位置，准备下一次对比
        }
    }


    public T delMin(){
        //先存一下要被删除的值
        T min = items[1];  //注意是从索引1开始
        container.add(min);
        //1.将根节点和末尾结点置换
        exch(1,N);
        //删除末尾结点(即原来根节点)
        items[N] =null;
        N--;
        //对新根结点下沉
        sink(1);
        //返回删除的结点
        return min;

    }

    //删除二叉堆第i位结点
    public T delete(int i){
        T del = items[i];//返回该结点在items里面的位置
        //置换i位结点和末尾结点
        exch(i,N);
        //把末尾结点删除，即原i位结点删除
        items[N]=null;
        //长度-1
        N--;
        //让i位的新结点下沉，让堆有序
        sink(i);
        //让i位的新结点上浮，让堆有序
        swim(i);
        //返回删除的结点内容
        return del;
    }

    //不满足堆序：父结点<子结点；即满足父结点>子结点就交换
    private void sink(int n) {
        //判断是否有子结点
        while(2*n<=N){
            int min = 2*n;//先定位到左儿子

            //如果右儿子存在且右儿子<左儿子，min指向右儿子
            if(2*n+1<=N && items[2*n+1].compareTo(items[min])<0){
                min = 2*n+1;
            }

            //如果父结点>子结点，交换；否则break;
            if(items[n].compareTo(items[min])>0){
                exch(n,min);
                n = min; //n指向min位置，向下走
            }else{
                break;
            }

        }//while结束
    }

    //堆排序
    private void sort(){
        while(!isEmpty()){ //当二叉堆结点尚存在，不停删除根结点，结果是对数组中的元素进行了降序排序
            delMin();
        }
    }

    private void exch(int i, int j) {
        T t = items[i];
        items[i] = items[j];
        items[j] = t;
    }

}
