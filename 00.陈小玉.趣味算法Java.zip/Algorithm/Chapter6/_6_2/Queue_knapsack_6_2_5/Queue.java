package Algorithm.Chapter6._6_2.Queue_knapsack_6_2_5;
//队列：通过单链表构造
//特点：FIFO(先进先出 / 后入后出)
//插入结点时，使用尾插法，使得后入的结点排在后面，从头结点开始，读取/删除结点达到：先入先出(后入后出)


public class Queue<T> {
    public Node head;
    public int N;

    public Queue(){
        this.head=new Node(null,null);
        this.N= 0;
    }

    public int size(){
        return N;
    }
    public boolean isEmpty(){
        return N==0;
    }

    public void enqueue(T t){
        if (head.next==null){
            Node newNode = new Node(t,null);
            head.next = newNode;
            N++;
        }else{
            Node n=head;
            while (n.next!=null){
                n =n.next;
            }
            Node newNode = new Node(t,null);
            n.next=newNode;
            N++;
        }
    }

    //跟栈一样，也是每次删除第一个结点：对于队列来说是删除先入结点
    public T dequeue(){
        if (isEmpty()) return null;

        Node n= head.next;
        T t = n.data;
        head.next=n.next;
        N--;
        return t;
    }

    public void print_data(){
        Node n = head;
        while (n.next!=null){
            n=n.next;
            System.out.print(n.data+" ");
        }
    }

    public class Node{
        T data;
        Node next;

        Node(T data ,Node next){
            this.data=data;
            this.next=next;
        }
    }

}
