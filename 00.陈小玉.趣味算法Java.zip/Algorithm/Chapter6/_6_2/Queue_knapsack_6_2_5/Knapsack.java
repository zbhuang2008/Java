package Algorithm.Chapter6._6_2.Queue_knapsack_6_2_5;
/*6.2.5  大卖场购物车3——0-1背包问题: 未优化：不用按[价格重量比]排序*/
import java.util.Scanner;

public class Knapsack {
    static boolean[] bestx;             //记录商品已经放入
    static Goods[] goods;               //商品对象数组
    static int n,W;                     //W为购物车最大容量; n为物品个数
    static double bestp;                //bestp 用来记录物品总价值的最优值;

    static void init(int W){            //W=W
        bestx=new boolean[W];
        goods=new Goods[W];

        for (int i=0;i<W;i++){
            goods[i]=new Goods();
        }
    }

    //商品类
    public static class Goods{
        int value;
        int weight;
    }

    //结点类
    public static class Node{
        double cp;                 //cp背包的物品总价值
        double rp;              //rp剩余物品的总价值
        int rw;                 //剩余容量
        int id;                 //物品号
        boolean[] x;            //解向量：默认为false

        //生成有数据的结点，填入数据
        Node(double cp,double rp,int rw,int id){
            this.x=new boolean[W];
            this.cp=cp;
            this.rp=rp;
            this.rw=rw;
            this.id=id;
        }
    }

    /*使用广度优先搜索遍历子树*/
    public static double bfs(double sumv){

        int t;
        double tcp;            //tcp背包的物品总价值
        double trp;            //trp剩余物品的总价值
        int trw;            //trw剩余容量

        Queue<Node> q =new Queue<>();                       //使用自行创建的队列类
        q.enqueue(new Node(0,sumv,W,1));            //压入一个初始结点
        while(!q.isEmpty()){                                //队列不为空
            //1.定义3个指针
            Node livenode,lchild,rchild;

            livenode=q.dequeue();                           //取出队头元素作为当前的扩展结点,livenode指针指向该结点
            t = livenode.id;                                //当前处理的物品序号

            //2.1.搜到最后一个物品的时候不需要往下搜索
            //2.2如果当前的购物车没有剩余容量了(已经装满了)，不再扩展
            if (t>n || livenode.rw==0){

                if (livenode.cp >= bestp){                  //(1)更新最优解和最优值
                    for (int i=1;i<=n;i++){
                        bestx[i]=livenode.x[i];
                    }
                    bestp=livenode.cp;                      //设置物品总价值的最优值
                }
                continue;
            }

            //3.1判断当前结点是否满足限界条件，如果不满足不再扩展
            if (livenode.cp + livenode.rp<bestp){
                continue;
            }

            //3.2满足限界条件
            //(1)扩展左孩子
            tcp = livenode.cp;                              //当前购物车中的总价值
            trp = livenode.rp - goods[t].value;             //当前购物车剩余总价值，不管当前物品装入与否，剩余价值都会减少。
            trw = livenode.rw;                              //购物车剩余容量

            if (trw >= goods[t].weight){                    //满足约束条件，可以放入购物车
                int rw = trw - goods[t].weight;
                double cp = tcp + goods[t].value;
                lchild = new Node(cp,trp,rw,t+1);       //创建左孩子结点，传递参数
                for (int i=1;i<t;i++){
                    lchild.x[i]=livenode.x[i];              // 复制父结点的解向量
                }

                //关键:左孩子当前的解向量设置为true
                lchild.x[t]=true;
                if (lchild.cp > bestp){                     //左孩子的物品总价值比最优解大才更新
                    bestp = lchild.cp;
                }
                q.enqueue(lchild);                          //左孩子入队

            } //if结束


            //(2)扩展右孩子
            if(tcp+trp>=bestp){                             //满足限界条件，不放入购物车
                rchild = new Node(tcp,trp,trw,t+1);
                for (int i=1;i<t;i++){
                    rchild.x[i] = livenode.x[i];            // 复制父亲结点的解向量
                }
                rchild.x[t] = false;
                q.enqueue(rchild);                          // 右孩子入队
            }
        }
        return bestp;                                       //返回物品总价值的最优解
    }

    static void knapsack(int n,int w){
        double sumw=0;                                              //用来统计所有物品的总重量
        double sumv=0;                                             //用来统计所有物品的总价值

        for (int i=1;i<=n;i++){
            sumw+= goods[i].weight;
            sumv+= goods[i].value;
        }

        if (sumw<=W){
            bestp=sumv;
            System.out.println("放入购物车的物品最大价值为："+bestp);
            System.out.println("所有的物品均放入购物车。");
            return;                                     //放入了就结束主方法
        }

        bfs(sumv);                                          //正在放入购物车，bfs()

        System.out.println("放入购物车的物品最大价值为："+bestp);
        System.out.println("放入购物车的物品序号为：");
        for (int i=1; i<=n;i++){                        //输出最优解
            if (bestx[i]){
                System.out.print(i+" ");                //打印已经放入的商品的序号
            }
        }//for结束
    }


    public static void main(String[] args){
        //输入物品的个数和背包的容量
        Scanner scanner = new Scanner(System.in);
        System.out.println("请输入物品的个数n:");
        n = scanner.nextInt();

        System.out.println("请输入购物车的容量：");
        W = scanner.nextInt();

        init(W);    //初始化

        System.out.println("请依次输入每个物品的重量w和价值v,用空格分开：");
        //读取物品重量w和物品价值v：Java先读取一行数据，然后按空格分割
        for (int i=1;i<=n;i++){
            goods[i].weight =scanner.nextInt();
            goods[i].value  =scanner.nextInt();
        }
        knapsack(n,W);
    }
}
