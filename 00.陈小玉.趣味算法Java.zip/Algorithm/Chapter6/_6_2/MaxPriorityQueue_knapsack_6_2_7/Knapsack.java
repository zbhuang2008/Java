package Algorithm.Chapter6._6_2.MaxPriorityQueue_knapsack_6_2_7;
/*6.2.7  大卖场购物车3——0-1背包问题:已经优化：按[价格重量比]排序
* 注意：请对比：5_2_2的代码：结构差不多，只是使用了辅助数组a,b，搜索方法换成backTrack(int t)
* */
import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

public class Knapsack {
    static boolean[] bestx;              //记录商品已经放入
    static Goods[] goods;                //商品对象数组
    static Object[] S;                   //辅助物品对象数组
    static int[] w;                      //w[i]表示第i个物品的重量
    static int[] v;                      //v[i]表示第i个物品的价值
    static int n,W ;                    //W为购物车最大容量; n为物品个数
    static double bestp;                //bestp 用来记录物品总价值的最优值


    static void init(int N,int W){      //N=n; W=w;
        bestx=new boolean[W];
        goods=new Goods[W];
        w =new int[W];
        v =new int[W];
        S = new Object[N];

        for (int i=0;i<W;i++){
            goods[i]=new Goods();
        }
        for(int i=0;i<N;i++){
            S[i]=new Object();
        }
    }

    //商品类
    static class Goods {
        int value;
        int weight;
    }

    //辅助类：定义辅助物品结构体，包含物品序号和单位重量价值，用于按单位重量价值(价值/重量比)排
    static class Object{
        int id;                     //物品序号
        double d;                   //单位重量价值
    }

    //结点类
    static class Node implements Comparable<Node> {
        int cp;                     //cp背包的物品总价值
        double up;                  //物品价值的上界
        int rw;                     //背包剩余容量
        int id;                     //物品号
        boolean[] x;                //解向量：默认为false

        //生成有数据的结点，填入数据
        Node(int cp,double up,int rw,int id){
            this.x=new boolean[W];
            this.cp=cp;
            this.up=up;
            this.rw=rw;
            this.id=id;
        }

        //最大优先队列的比较方法,默认>是true
        @Override
        public int compareTo(Node node) {
            if (this.up>node.up){
                return 1;
            }else if (this.up<node.up){
                return -1;
            }else{
                return 0;
            }
        }
    }

    //对Object自定义排序规则:降序排序
    static class cmp<A extends Knapsack.Object> implements Comparator<A> {
        @Override
        public int compare(A a1, A a2) {
            if (a1.d<a2.d)
                return 1;
            else if (a1.d>a2.d)     //满足降序，排序
            	return -1;
            else
            	return 0;
        }
    }


    /*使用广度优先搜索遍历子树*/

    //计算左儿子上界的方法
    static double bound(Node tnode){
        double maxValue = tnode.cp;         //已经装入购物车的物品价值
        int t = tnode.id;                   //排序后的序号
        double left=tnode.rw;               //剩余容量
        while (t<=n && w[t]<=left){
            maxValue+=v[t];
            left-= w[t];
            t++;
        }
        if (t<=n){
            maxValue+=1.0*v[t]/w[t]*left;
        }
        return maxValue;
    }

    static void knapsack(int n,int W){
        double sumw=0;                                              //用来统计所有物品的总重量
        double sumv=0;                                             //用来统计所有物品的总价值

        //从下标1开始，标记每一个商品的 id和 [价值重量比]，下面再根据[价值重量比]对购物车的商品排序
        for(int i=1;i<=n;i++) {

            S[i-1].id=i;
            S[i-1].d = goods[i].value/goods[i].weight;              //[价值重量比]
            sumw+= goods[i].weight;
            sumv+= goods[i].value;
        }

        if (sumw<=W){
            bestp=sumv;
            System.out.println("放入购物车的物品最大价值为："+bestp);
            System.out.println("所有的物品均放入购物车。");
            return; //放入了就结束主方法
        }

        //按 [价值重量比] 递减排序
        Arrays.sort(S,new cmp());

        System.out.println("放入购物车的物品序号按【价值重量比】从大到小排序：");
        for (int i=1;i<=n;i++){
            w[i]=goods[S[i-1].id].weight;               //把排序后的数组传递给w,v;
            v[i]=goods[S[i-1].id].value;
        }


        bfs(sumv);                                     //优先队列分支限界法搜索

        System.out.println("\n放入购物车的物品最大价值为："+bestp);
        System.out.println("放入购物车的物品序号为：");
        for (int i=1; i<=n;i++){                        //输出最优解
            if (bestx[i]){
                System.out.print(S[i-1].id+" ");        //检测已经放入的商品，然后根据
            }
        }//for结束
    }

    /*广度优先搜索*/
    static double bfs(double sumv){
        int t;
        int tcp;                                                    //tcp背包的物品总价值
        int trw;                                                    //trw剩余容量

        MaxPriorityQueue<Node> q =new MaxPriorityQueue<>(W);        //使用最大优先队列
        q.insert(new Node(0,sumv,W,1));                     //压入一个初始结点
        while(!q.isEmpty()){                                        //队列不为空

            Node livenode,lchild,rchild;                            //1.定义3个指针

            livenode=q.delMax();                                    //取出最大元素作为当前的扩展结点,livenode指针指向该结点
            t = livenode.id;                                        //当前处理的物品序号

            //2.1.搜到最后一个物品的时候不需要往下搜索
            //2.2如果当前的购物车没有剩余容量了(已经装满了)，不再扩展
            if (t>n || livenode.rw==0){

                if (livenode.cp >= bestp){                          //(1)更新最优解和最优值
                    for (int i=1;i<=n;i++){
                        bestx[i]=livenode.x[i];
                    }
                    bestp=livenode.cp;                              //设置物品总价值的最优值
                }
                continue;
            }

            //3.1判断当前结点是否满足限界条件，如果不满足不再扩展
            if (livenode.up < bestp){
                continue;
            }

            //3.2满足限界条件
            //(1)扩展左孩子 (此处有改)
            tcp = livenode.cp;                                  //当前购物车中的总价值
            trw = livenode.rw;                                  //购物车剩余容量

            if (trw >= w[t]){ //满足约束条件，可以放入购物车
                lchild=new Node(0,0,0,0);
                lchild.cp = tcp + v[t];
                lchild.rw = trw - w[t];
                lchild.id = t+1;
                lchild.up = bound(lchild);                         //计算左孩子上界


                for (int i=1;i<t;i++){
                    lchild.x[i]=livenode.x[i];                     // 复制以前的解向量
                }

                //关键:左孩子当前的解向量设置为true
                lchild.x[t]=true;
                if (lchild.cp > bestp){                           //左孩子的物品总价值比最优解大才更新
                    bestp = lchild.cp;
                }
                q.insert(lchild);                                //左孩子入队

            } //if结束


            //(2)扩展右孩子
            rchild=new Node(0,0,0,0);
            rchild.cp=tcp;
            rchild.rw=trw;
            rchild.id=t+1;
            rchild.up=bound(rchild);

            if(rchild.up>=bestp){                                 //满足限界条件，不放入购物车

                for (int i=1;i<t;i++){
                    rchild.x[i] = livenode.x[i];                // 复制以前的解向量
                }
                rchild.x[t] = false;
                q.insert(rchild); // 右孩子入队
            }
        }
        return bestp;//返回物品总价值的最优解
    }

    public static void main(String[] args){
        //输入物品的个数和背包的容量
        Scanner scanner = new Scanner(System.in);
        System.out.println("请输入物品的个数n:");
        n = scanner.nextInt();

        System.out.println("请输入购物车的容量：");
        W = scanner.nextInt();

        init(n,W);    //初始化

        System.out.println("请依次输入每个物品的重量w和价值v,用空格分开：");

        //读取物品重量w和物品价值v：Java先读取一行数据，然后按空格分割
        for (int i=1;i<=n;i++){
            goods[i].weight = scanner.nextInt();
            goods[i].value  = scanner.nextInt();
        }
        knapsack(n,W);
    }
}
