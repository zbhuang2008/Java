package Algorithm.Chapter6._6_4;
/*6.4铺设电缆-最优工程布线*/

import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Wiring {
   private int[][] grid;                    //地图，用m,n构造，尽量不预设长度
   private int PathLen;                     //记录每跳一格，当前的路径长度
   private Position[] path;                 //记录格子的坐标系(x,y)-Position对象
   private Position here;                   //当前格指针here
   private Position next;                   //下一格结点 next:注意每次使用都要重新生成对象


    /*初始化地图，标记大于0表示已布线，未布线-1，墙壁-2*/
    Wiring(int m,int n){
        this.grid=new int[m+2][n+2];        //为了建立围墙，故扩展长度
        for(int i=1; i<=m; i++)             //方格阵列初始化为-1
            for(int j=1; j<=n; j++)
                grid[i][j]=-1;
        for (int i=0;i<=n+1;i++)            //方格列阵上下围墙
            grid[0][i]=grid[m+1][i]=-2;
        for (int i=0;i<=m+1;i++)            //方格列阵左右围墙
            grid[i][0]=grid[i][n+1]=-2;

    }

    public static class Position{
        int x;
        int y;
    }

   /* 打印矩阵*/
    public void print_G(){
        for(int[] t:this.grid){
            for (int tm:t){
                System.out.print(tm+" ");
            }
            System.out.println("\n");
        }
    }

    /*寻找路径*/
    public boolean findPath(Position s,Position e){
        if ((s.x == e.x) && (s.y == e.y)){      //判定开始位置是否就是目标位置
            PathLen=0;
            return true;
        }

        Position[] DIR = new Position[4];       //定义方向数组DIR[4]
        for (int i=0;i<4;i++){                 //初始化方向数组
            DIR[i]=new Position();
        }
        DIR[0].x=0; DIR[0].y=1;
        DIR[1].x=1; DIR[1].y=0;
        DIR[2].x=0; DIR[2].y=-1;
        DIR[3].x=-1;DIR[3].y=0;

        here=s;                              //here指向开始的结点s
        grid[s.x][s.y]=0;                 //当前起点标记为0，未布线-1，墙壁-2
        Queue<Position> Q = new LinkedList<>();    //创建存储Position对象的队列

        while (true){
            //4个方向的前进，右下左上
            for(int i=0;i<4;i++){
                next=new Position(); //每次都要生成新的next
                next.x=here.x+DIR[i].x;
                next.y=here.y+DIR[i].y;

                if (grid[next.x][next.y] ==-1){          //尚未布线
                    grid[next.x][next.y]=grid[here.x][here.y]+1;
                    Q.add(next);
                }
                if ((next.x==e.x) && (next.y==e.y))   //判断下一个格子是不是终点，是则找到目标
                    break;
            }//for

            //上下左右都找完了
            if ((next.x==e.x) && (next.y==e.y))     //判断下一个格子是不是终点，是则找到目标
                break;

            if (Q.isEmpty()){
                return false;
            }else{
                here =Q.poll();
            }

        } //while

        //逆向找回最短布线方案
        PathLen = grid[e.x][e.y];                       //取得最终格子存储的路径长度(走的格子数)
        path=new Position[PathLen];                     //创建路径结点数组，结点是坐标系(x,y)

        here=e;                                         //当前的终点格子对象
        for (int j=PathLen-1;j>=0;j--){                 //从末尾开始记录路径对象
            path[j]=here;

            next = new Position();
            for (int i=0;i<4;i++){ //沿着4个方向寻找，右下左上
                next.x=here.x+DIR[i].x;
                next.y=here.y+DIR[i].y;

                if (grid[next.x][next.y]==j)break;  //找到相同的长度，终止小for循环
            }
            here=next;                              //here指针指向下一个格子
        }
        return true;
    }



   public static void main(String[] args){
       Position a =new Position();
       Position b =new Position();
       int m,n;
       Scanner scanner = new Scanner(System.in);

       System.out.println("请输入方阵大小M,N:");  //第一行输入不用吸收回车
        m=scanner.nextInt();
        n=scanner.nextInt();

       //初始化图
       Wiring wiring=new Wiring(m,n);
       while (!(m==0 && n==0)){    //循环不用吸收回车，输入不是0 0时进行
           System.out.println("请输入障碍物坐标x y(输入0 0结束)"); //设置墙壁
           m=scanner.nextInt();
           n=scanner.nextInt();
           wiring.grid[m][n]=-2;
       }

       System.out.println("请输入起点坐标：");
        a.x=scanner.nextInt();
        a.y=scanner.nextInt();


        System.out.println("请输入终点坐标：");
        b.x=scanner.nextInt();
        b.y=scanner.nextInt();

        boolean find = wiring.findPath(a,b);

        if (find){
            System.out.println("该条最短路径的长度为:"+wiring.PathLen);
            System.out.println("最佳路径坐标为：");
            for (int i=0;i<wiring.PathLen;i++){
                System.out.println(wiring.path[i].x+" "+wiring.path[i].y);
            }
        }else{
            System.out.printf("任务无法达成");
        }
   }
}
