package Algorithm.Appendix.UF_Tree;
//并查集——朴素方法
public class UF_Tree {
    //记录结点元素和该元素的父结点
    private int[] eleAndGroup;
    //记录并查集的数组分组个数
    private int count;

    public UF_Tree(int N){
        //初始情况下，每个元素都在一个独立的分组中，所以，初始情况下，并查集中的数据默认分为N个组
        this.count = N;
        //初始化数组
        eleAndGroup = new int[N];
        //把eleAndGroup数组的索引看做是每个结点存储的元素，把eleAndGroup数组每个索引处的值看做是该
        //结点的父结点，那么初始化情况下，i索引处存储的值就是i
        for(int i=0;i<N;i++){
            eleAndGroup[i] = i;
        }

    }

    //获取当前并查集有多少分组
    public int getCount(){
        return count;
    }

    //找元素p所在分组的父结点
    public int find(int p){
        while (true){
            //判断当前元素p的父结点是不是自己，是的话则证明已经是根结点了
            if (p==eleAndGroup[p]){
                return p;
            }

            //如果当前元素p的父结点不是自己，则让p=eleAndGroup[p]，继续找父结点的父结点,直到找到根
            //结点为止；
            p=eleAndGroup[p];

        }
    }

    //判断并查集中元素p和q是否是同一个父结点
    public boolean connected(int p,int q){
        return find(p)==find(q);
    }

    //把p元素所在分组和q元素所在分组合并
    //这里的参数有顺序意义：把p结点父结点的父结点改成q的父结点，说明q合并了p
    public void union(int p,int q){
        //1.找到p，q的父结点：也可以看做p所在子树的根pRoot; q所在子树的根qRoot
        int pRoot = find(p);
        int qRoot = find(q);

        //2.如果p，q父结点一样，说明在同一棵树,无需合并
        if (pRoot==qRoot){
            return;
        }
        //3.若p,q父结点不同，把p的父结点的父结点改成q的父结点，
        eleAndGroup[pRoot] = qRoot;

        //4.分组数量-1
        count--;
    }
}
