package Algorithm.Appendix;
/*5.6机器零件加工——最优加工顺序:附录G代码，求所有加工机器零件的顺序——构造排列树*/
import java.util.Scanner;

public class G {
	static int[] x;          //存放解分量
    static int f1,f2;       //f1表示当前第一台机器上加工的完成时间,f2表示当前第二台机器上加工的完成时间
	static int n;          //元素个数


	static void init(int N){						//N=n+1
		x=new int[N];
	}

	public static void myarray(int t) {
		if(t>n) {                                     //到达叶子结点           
			for(int i=1;i<=n;i++)                     //输出排列组合
				System.out.print(x[i]+" ");
			System.out.println();
			return;
		}
		
		int temp;
		for(int i=t;i<=n;i++) {                       //枚举
			//swap(x[t],x[i]);                        //进行交换
			temp=x[t];
			x[t]=x[i];
			x[i]=temp;
			myarray(t+1);                             //向下一层进行搜索
			//swap(x[t],x[i]);                        //回溯时进行再次交换
			temp=x[t];
			x[t]=x[i];
			x[i]=temp;
		}
	}

    public static void main(String[] args) {
        System.out.println("输入排列的元素个数n（求1..n的排列）：");
        Scanner scanner=new Scanner(System.in);
        n=scanner.nextInt();

        init(n+1);

        for(int i=1;i<=n;i++)
            x[i]=i;

        myarray(1);                                   //得到排列组合
        scanner.close();
    }
	
}