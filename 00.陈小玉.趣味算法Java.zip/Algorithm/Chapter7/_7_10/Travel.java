package Algorithm.Chapter7._7_10;
/*7.10  走着走着，就走到了西藏——旅游路线问题：MCMF算法*/
import java.util.*;

public class Travel {
    static final double INF=Double.POSITIVE_INFINITY;
    static int top;                            //当前边下标
    static double[] dist;                      //dist[i]表示源点到点i最短距离
    static int[] pre;                         //pre[i]记录前驱
    static boolean[] vis;                    //标记数组,默认是false，故不用初始化
    static int[] c;                          //入队次数,默认是0，故不用初始化
    static Vertex[] V;                       //结点数组
    static Edge[] E;                        //边数组
    static String[] str;                    //多了这个用来存储途径景点的字符串数组
    static Map<String,Integer> maze;        //使用键值对
    static double maxflow,mincost;          //当前最大流,最小流

    /*初始化*/
    public static void init(int N,int M){
        dist=new double[N];
        pre=new int[N];
        vis=new boolean[N];
        c = new int[N];
        V=new Vertex[N];
        E = new Edge[M];
        str=new String[M];
        maze=new HashMap<>();

        for (int i=0;i<N;i++){
            V[i]=new Vertex(-1);    //生成结点对象，结点邻接边初始化为-1
            pre[i]=-1;                  //前驱初始化为-1
        }
        for (int i=0;i<M;i++){
            E[i]=new Edge();            //生成边对象
        }
        top=0;
        maxflow=0;
    }

    /*结点类*/
    public static class Vertex{
        int first;
        Vertex(int first){
            this.first=first;
        }
    }
    /*边类*/
    public static class Edge{
        int v,next;
        double cap,flow,cost;

    }

    /*添加边*/
    public static void add_edge(int u,int v,int c,int cost){
        E[top].v=v;
        E[top].cap=c;
        E[top].flow=0;
        E[top].cost=cost;
        E[top].next=V[u].first;
        V[u].first=top++;
    }

    /*实现有向图的边*/
    public static void add(int u,int v,int c,int cost){
        add_edge(u,v,c,cost);
        add_edge(v,u,0,-cost);
    }

    /*求最小费用路径的SPFA:单源最短路径算法,采用bfs搜索*/
    public static boolean SPFA(int s,int t,int n){
        int i,u,v;
        Queue<Integer> qu = new LinkedList<>();

        /*必须要每次重新初始化,因为SPFA会调用多次*/
        Arrays.fill(vis,false);
        Arrays.fill(c,0);
        Arrays.fill(dist,INF);  //距离初始化为INF

        vis[s]=true;                            //开始结点入队，标记为true
        c[s]++;                                 //统计入队次数
        dist[s]=0;                              //起点路径设为0
        qu.add(s);
        while (!qu.isEmpty()){
            u=qu.poll();
            vis[u]=false;

            //队头元素出队，并消除标记
            for (i=V[u].first; i!=-1; i=E[i].next){ //遍历结点u的邻接表
                v = E[i].v;
                if (E[i].cap > E[i].flow && dist[v]>dist[u]+E[i].cost){ //松弛操作
                    dist[v]=dist[u]+E[i].cost;
                    pre[v]=i;                                       //记录前驱
                    if (!vis[v]){                                   //结点v不在队内
                        c[v]++;
                        qu.add(v);                                  //入队
                        vis[v]=true;                                //标记
                        if (c[v]>n)                                 //超过入队上限，说明有负环
                            return false;
                    }
                }
            }
        }//while

        if (dist[t]==INF)
            return false;       //如果距离是INF，说明无法到达，返回false

        return true;
    }

    /*求最大流的最小费用*/
    public static double MCMF(int s,int t,int n){   //s:起点，t:终点，n:结点数量
        double d=0;              //可增流量
        maxflow=mincost=0;      //maxflow 当前最大流量，mincost当前最小费用


        while (SPFA(s,t,n)){    //是单源最短路径时才找最小可增流量
            d=INF;
            for (int i=pre[t]; i!=-1; i=pre[E[i^1].v]){
                d=Math.min(d,E[i].cap-E[i].flow);   //找最小可增流量
            }

            /*增流：d ； 增广路径：t*/

            for (int i=pre[t]; i!=-1; i=pre[E[i^1].v]){ //增广路上正向边流量+d，反向边流量-d
                E[i].flow+=d;
                E[i^1].flow-=d;
            }

            maxflow+=d;             //更新最大流
            mincost+=dist[t]*d;     //dist[t]为该路径上单位流量费用之和，最小费用更新
        }
        return maxflow;
    }

    /*输出网络邻接表*/
    public static void printg(int n){
        System.out.println("----------网络邻接表如下------------");
        for (int i=1;i<=n;i++){
            System.out.print("v"+i+"  ["+V[i].first);

            for (int j=V[i].first;j>=~j;j=E[j].next){
                System.out.print("]--["+E[j].v+"  "+E[j].cap+"  "+E[j].flow+"  "+
                                        E[j].cost+"  "+E[j].next+"]");
            }
            System.out.println();
        }
    }


    /*输出实流边:改写*/
    public static void printflow(int s,int t){
        int v;
        vis[s]=true;    //标记起点s
        for (int i=V[s].first;i!=-1;i=E[i].next){
            if (!vis[v=E[i].v] && ( (E[i].flow>0 && E[i].cost<=0) || (E[i].flow<0 && E[i].cost>=0))){
                printflow(v,t); //递归
                if (v<=t)
                    System.out.println(str[v]);
            }
        }
    }


    public static void main(String[] args){
        int n,m,i;
        String str1,str2;
        Scanner scanner = new Scanner(System.in);
        System.out.println("请输入景点个数n和直达线路数m：");
        n=scanner.nextInt();
        m=scanner.nextInt();

        init(n*100,m*100);                  //初始化:N,M尽量大
        maze.clear();//清除内容

        System.out.println("请输入景点名str：");
        scanner.nextLine();                          //吸收空行
        for (i=1;i<=n;i++){
            str[i] = scanner.nextLine().trim();      //记得去除空格，因为复制信息时有可能会把空格复制进去
            maze.put(str[i],i);
            if (i==1 || i==n)
                add(i,i+n,2,0);
            else
                add(i,i+n,1,0);
        }

        System.out.println("请输入可以直达的两个景点名str1,str2：");
        for (i=1;i<=m;i++){
            str1=scanner.next().trim();             //记得去除空格，因为复制信息时有可能会把空格复制进去
            str2=scanner.next().trim();

            int a=maze.get(str1);
            int b=maze.get(str2);

            if (a<b){
                if (a==1 && b==n)
                    add(a+n,b,2,-1);
                else
                    add(a+n,b,1,-1);
            }else {
                if (b==1 && a==n)
                    add(b+n,a,2,-1);
                else
                    add(b+n,a,1,-1);
            }

        }

        if (MCMF(1,2*n,2*n)==2){
            System.out.println("最多经过的景点个数："+-mincost);
            System.out.println("依次经过的景点：");
            System.out.println(str[1]);
            /*重点，访问标记重新初始化*/
            Arrays.fill(vis,false);
            printflow(1,n);
            System.out.println(str[1]);
        }else{
            System.out.println("No Solution!");
        }
    }
}

