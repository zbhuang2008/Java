package Algorithm.Chapter7._7_8;
/*7.8太空实验计划——最大收益问题:优化的ISAP+DFS算法：添加了DFS算法，修改printflow()和main()*/
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class MaxProfit {
    static final double INF=Double.POSITIVE_INFINITY;
    static int top;
    static int[] h;             //h[]数组记录每个结点的高度，即到汇点的最短距离。
    static int[] g;             //g[]数组记录距离为h[]的结点的个数，例如g[3]=1，表示距离为3的结点个数为1个
    static int[] pre;           // pre[]记录当前结点的前驱边，pre[v]=i，表示结点v的前驱边为i，即搜索路径入边
    static Vertex[] V;          //结点数组
    static Edge[] E;            //边数组
    static boolean[] flag;      //添加多一个flag标记数组，用于DFS方法，默认false

    /*初始化*/
    public static void init(int N,int M){
        h=new int[N];
        g=new int[N];
        pre=new int[N];
        V = new Vertex[N];
        E = new Edge[M];
        flag=new boolean[N];

        for (int i=0;i<N;i++){
            h[i]=-1;                            //初始化高度函数为-1
            V[i]=new Vertex(-1);          //初始化邻接表头结点第一个邻接边为-1
        }
        for (int i=0;i<M;i++){
            E[i]=new Edge();
        }
        top=0;
    }

    //结点结构体
    public static class Vertex{
        int first;                                      //邻接表头结点第一个邻接边
        Vertex(int first){
            this.first=first;
        }
    }
    //边结构体
    public static class Edge{
        int v,next;
        int flow;
        double cap;
    }

    /*创建边*/
    public static void add_edge(int u,int v,double c){
        //输入数据格式：u v及边（u--v）的容量c
        E[top].v=v;
        E[top].cap=c;
        E[top].flow=0;
        E[top].next=V[u].first;                 //连接到邻接表中
        V[u].first=top++;
    }

    /*添加两条边,因为是有向图，u->v:权值=c; v->u不存在，权值设置为0*/
    public static void add(int u, int v, double c){
        add_edge(u,v,c);
        add_edge(v,u,0);
    }

    /*标高函数——使用bfs广度优先搜索*/
    public static void set_h(int t,int n){
        Queue<Integer> Q = new LinkedList<>();          //创建bfs用的队列
        Arrays.fill(h,-1);                          //重点：对h[],g[]清空
        Arrays.fill(g,0);
        h[t]=0;                                         //初始化汇点高度为0
        Q.add(t);                                       //入队
        while (!Q.isEmpty()){
            int v = Q.poll();
            ++g[h[v]];
            for (int i = V[v].first; i>=~i; i=E[i].next){   //读结点v的邻接边标号:注意是大于等于自反值
                int u = E[i].v;
                if (h[u]==-1){
                    h[u]=h[v]+1;
                    Q.add(u);
                }
            }
        }//while
    }

    public static int Isap(int s,int t,int n){
        set_h(t,n);                                         //标高函数
        int ans=0;
        int u=s;
        double d = 0;

        while (h[s]<n){
            int i = V[u].first;                             //while中的i统一使用这个

            if (u==s)
                d=INF;

            for(;i>=~i;i=E[i].next){
                int v=E[i].v;                                //搜索当前结点的邻接边
                if (E[i].cap > E[i].flow && h[u]==h[v]+1){  //沿有可增量和高度减1的方向搜索
                    u=v;
                    pre[v]=i;
                    d=Math.min(d,E[i].cap-E[i].flow);       //最小增量

                    if (u==t){
                        while (u!=s){                   //从汇点向前，沿增广路径一直搜索到源点
                            int j=pre[u];              //j为u的前驱边，即增广路上j为u的入边
                            E[j].flow+=d;             //j边的流量+d
                            E[j^1].flow-=d;           //j的反向边的流量-d
                            u=E[j^1].v;
                         }//while
                        ans+=d;
                        d=INF;
                    }
                    break;                           //找到一条可行邻接边，退出for语句，继续向前走
                }//大if
            }//for

            if (i==-1){                             //当前结点的所有邻接边均搜索完毕，无法行进
                if (--g[h[u]]==0)                   //如果该高度的结点只有一个，算法结束
                    break;
                int hmin=n-1;
                for (int j=V[u].first;j>=~j;j=E[j].next){    //搜索u的所有邻接边
                    if(E[j].cap>E[j].flow)                  //有可增量
                        hmin=Math.min(hmin,h[E[j].v]);      //取所有邻接点高度的最小值
                }//for

                h[u]=hmin+1;
                ++g[h[u]];                              //重新标高后该高度的结点数+1
                if (u!=s)                               //如果当前结点不是源点
                    u=E[pre[u]^1].v;                    //向前退回一步，重新搜索增广路
            }//if(i==-1)

        }//while
        return ans;
    }

    /*使用DFS.深度优先搜索获取最大获益方案*/
    public static void DFS(int s){
        for (int i=V[s].first; i>=~i; i=E[i].next){     //读当前结点的邻接表
            if (E[i].cap > E[i].flow){
                int u=E[i].v;
                if (!flag[u]){
                    flag[u]=true;
                    DFS(u);
                }
            }
        }
    }


    /*输出网络邻接表*/
    public static void printg(int n){
        System.out.println("-----------网络邻接表如下：-----------");
        for (int i=1;i<=n;i++){
            System.out.print("v"+i+"  ["+V[i].first);

            for (int j=V[i].first;j>=~j;j=E[j].next)
                System.out.print("]--["+E[j].v+"  "+E[j].cap+"  "+E[j].flow+"  "+E[j].next);
            System.out.println("]");
        }
    }

    /*输出实流边:输出最佳方案*/
    public static void printflow(int m,int n){              //注意这里多了参数n
        System.out.println("------------最大获益方案如下：---------------");
        DFS(0);                                         //从起始序号:0开始深度遍历
        System.out.print("选中的实验编号: ");
        for (int i=1;i<=m;i++)                             //遍历m,读每个代表团的邻接表
            if (flag[i])
                System.out.print(i+" ");

        System.out.print("\n选中的仪器编号：");
        for (int i=m+1;i<=m+n;i++)
            if (flag[i])
                System.out.print(i-m+" ");
    }



    /*修改主方法: cost作为流量flow*/
    public static void main(String[] args){
        int n,m,total,sum=0;                        //多了total,sum
        int cost,num;                               //多了num
        Scanner scanner = new Scanner(System.in);
        System.out.println("请输入实验数m和仪器数n：");
        m=scanner.nextInt();
        n=scanner.nextInt();

        init(n*100,m*100);                  //N,M尽量往大预设
        total = m+n;                                //统计员工总人数

        System.out.println("请依次输入实验产生的效益和该实验需要的仪器编号（为0结束）：");
        for (int i=1;i<=m;i++){
            cost=scanner.nextInt();
            sum+=cost;
            add(0,i,cost);                      //源点到题型的边，容量为该题型选择数量

            num=scanner.nextInt();
            while (num!=0){                         //num为试题j属于的题型号，为0时结束
                add(i,m+num,INF);               //题型号num到试题j的边，容量为INF,因为printflow以flag[i]为准，
                num=scanner.nextInt();              // 不再以容量为判断条件，所以设为INF
            }
        }

        System.out.println("请依次输入所有仪器的费用：");
        for (int j=m+1;j<=total;j++){
            cost=scanner.nextInt();
            add(j,total+1,cost);                //试题j到汇点的边，容量为1
        }
        System.out.println();

        System.out.println("最大净收益："+(sum-Isap(0,total+1,total+2))+"\n"); //注意规范，表达式要框住

        printflow(m,n);                             //输出最佳方案
    }
}
