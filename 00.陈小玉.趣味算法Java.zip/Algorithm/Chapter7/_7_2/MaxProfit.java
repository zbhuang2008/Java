package Algorithm.Chapter7._7_2;
/*7.2工厂最大效益——单纯形算法*/

import java.util.Scanner;

public class MaxProfit {
    static float[][] kernel=new float[100][100]; //存储非单纯形表：表的长度预设好，尽量大于n,m
    static char[] FJL=new char[100];            //非基本变量
    static char[] JL=new char[100];             //基本变量
    static int n,m;                            //n：行数 m：列数

    public static void DCXA(){
        int e=-1;                               //记录入基列
        int k=-1;                               //记录离基行

        while (true){
            float max1=0;                       //存放最大的检验数
            float max2=0;                       //存放最大的正检验数对应的基本变量的最大系数
            float min=100000000;

            for (int j=1;j<=m;j++){             //找入基列
                if (max1<kernel[0][j]){
                    max1=kernel[0][j];
                    e=j;
                }
            }
            if (max1<=0){
                System.out.println("获得最优解:"+kernel[0][0]);
                break;
            }

            for (int i=1;i<=n;i++){     //找离基行(常数列/入基列正比值最小对应的行)
                if (max2<kernel[i][e]){
                    max2=kernel[i][e];
                }
                float temp = kernel[i][0]/kernel[i][e];
                if (temp>0 && temp<min){
                    min=temp;
                    k=i;
                }
            }
            System.out.print("基列变量："+"x"+FJL[e]+" ");
            System.out.println("离基变量："+"x"+JL[k]);

            if (max2==0){
                System.out.println("解无界");
                break;
            }

            //变基变换(转轴变换)
            char temp=FJL[e];
            FJL[e]=JL[k];
            JL[k]=temp;

            for (int i=0;i<=n;i++){     //计算除入基列和出基行的所有位置的元素
                if (i!=k){
                    for (int j=0;j<=m;j++){
                        if (j!=e){
                            if (i==0 && j==0)
                                kernel[i][j]=kernel[i][j]+kernel[i][e]*kernel[k][j]/kernel[k][e];
                            else
                                kernel[i][j]=kernel[i][j]-kernel[i][e]*kernel[k][j]/kernel[k][e];
                        }
                    }//for
                }//if
            }//大for

            for (int i=0;i<=n;i++){     //计算特殊位，离基行的元素
                if (i!=k)
                    kernel[i][e]=-kernel[i][e]/kernel[k][e];
            }
            for (int j=0;j<=m;j++){     //计算特殊位，入基列的元素
                if (j!=e)
                    kernel[k][j]=kernel[k][j]/kernel[k][e];
            }
            kernel[k][e]=1/kernel[k][e];    //计算特殊位，交叉位置
            print();
        }//while
    }

    public static void print(){
        System.out.println("--------------单纯形表如下------------");
        System.out.printf("%7s","b ");
        for (int i=1;i<n;i++)           //此处与书本有一点不同，i<=n不对，i==n时FJL[n]为空，打印出:"x"没数字
            System.out.printf("%7s","x"+FJL[i]);
        System.out.println();
        System.out.print("c ");
        for (int i=0;i<=n;i++){
            if (i>=1)
                System.out.print("x"+JL[i]+" ");
            for (int j=0;j<=m;j++)
                System.out.printf("%7s",kernel[i][j]);
            System.out.println();
        }
    }



    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);

        System.out.println("输入非基本变量个数和非基本变量下标：");
        m=scanner.nextInt();                                     //列数
        for (int i=1;i<=m;i++)
            FJL[i]= (char) (scanner.nextInt()+48);      //把数值转成char:对应在ASCII表中相差48

        System.out.println("输入基本变量个数和基本变量下标：");
        n=scanner.nextInt();                                    //行数
        for (int i=1;i<=n;i++)
            JL[i]=(char)(scanner.nextInt()+48);         //把数值转成char:对应在ASCII表中相差48

        System.out.println("输入约束标准型初始单纯形表参数：");
        for (int i=0;i<=n;i++){
            for (int j=0;j<=m;j++){
                kernel[i][j]=scanner.nextFloat();
            }
        }
        print();
        DCXA();
    }
}
