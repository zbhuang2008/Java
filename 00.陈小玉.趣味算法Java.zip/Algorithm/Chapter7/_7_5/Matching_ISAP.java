package Algorithm.Chapter7._7_5;
/*7.5精明的老板——配对方案问题:使用ISAP算法
* 女推销员数量m; 男推销员编号n
* 女推销员编号u; 男推销员编号v , 男女之间期望值c或w,默认为1
* */

import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Matching_ISAP {
    static final double INF=Double.POSITIVE_INFINITY;
    static int top;
    static int[] h;          //h[]数组记录每个结点的高度，即到汇点的最短距离。
    static int[] g;          //g[]数组记录距离为h[]的结点的个数，例如g[3]=1，表示距离为3的结点个数为1个
    static int[] pre;        // pre[]记录当前结点的前驱边，pre[v]=i，表示结点v的前驱边为i，即搜索路径入边
    static Vertex[] V;      //结点数组
    static Edge[] E;        //边数组

    /*初始化*/
    public static void init(int N,int M){
        h=new int[N];
        g=new int[N];
        pre=new int[N];
        V = new Vertex[N];
        E = new Edge[M];

        for (int i=0;i<N;i++){
            h[i]=-1;                            //初始化高度函数为-1
            V[i]=new Vertex(-1);          //初始化邻接表头结点第一个邻接边为-1
        }
        for (int i=0;i<M;i++){
            E[i]=new Edge();
        }
        top=0;
    }

        //结点结构体
    public static class Vertex{
        int first;                      //邻接表头结点第一个邻接边
        Vertex(int first){
            this.first=first;
        }
    }
    //边结构体
    public static class Edge{
        int v,next;
        int cap,flow;
    }


    /*创建边*/
    public static void add_edge(int u,int v,int c){
        //输入数据格式：u v及边（u--v）的期望值c
        E[top].v=v;
        E[top].cap=c;
        E[top].flow=0;
        E[top].next=V[u].first;     //连接到邻接表中
        V[u].first=top++;
    }

    /*添加两条边,因为是有向图，u->v:期望值=c; v->u不存在，权值设置为0*/
    public static void add(int u,int v,int c){
        add_edge(u,v,c);
        add_edge(v,u,0);
    }

    /*标高函数——使用bfs广度优先搜索*/
    public static void set_h(int t,int n){
        Queue<Integer> Q = new LinkedList<>();          //创建bfs用的队列
        h[t]=0;                                         //初始化汇点高度为0
        Q.add(t);                                       //入队
        while (!Q.isEmpty()){
            int v = Q.poll();
            ++g[h[v]];
            for (int i = V[v].first; i>=~i; i=E[i].next){   //读结点v的邻接边标号:注意是大于等于自反值
                int u = E[i].v;
                if (h[u]==-1){
                    h[u]=h[v]+1;
                    Q.add(u);
                }
            }
        }//while
    }

    public static int Isap(int s,int t,int n){
        set_h(t,n);                                         //标高函数
        int ans=0;
        int u=s;
        double d = 0;

        while (h[s]<n){
            int i = V[u].first;                             //while中的i统一使用这个

            if (u==s)
                d=INF;

            for(;i>=~i;i=E[i].next){
                int v=E[i].v;                                //搜索当前结点的邻接边
                if (E[i].cap > E[i].flow && h[u]==h[v]+1){  //沿有可增量和高度减1的方向搜索
                    u=v;
                    pre[v]=i;
                    d=Math.min(d,E[i].cap-E[i].flow);       //最小增量

                    if (u==t){
                        while (u!=s){                   //从汇点向前，沿增广路径一直搜索到源点
                            int j=pre[u];              //j为u的前驱边，即增广路上j为u的入边
                            E[j].flow+=d;             //j边的流量+d
                            E[j^1].flow-=d;           //j的反向边的流量-d
                            u=E[j^1].v;
                         }//while
                        ans+=d;
                        d=INF;
                    }//小if
                    break;                           //找到一条可行邻接边，退出for语句，继续向前走
                }//大if
            }//for

            if (i==-1){                             //当前结点的所有邻接边均搜索完毕，无法行进
                if (--g[h[u]]==0)                   //如果该高度的结点只有一个，算法结束
                    break;
                int hmin=n-1;
                for (int j=V[u].first;j>=~j;j=E[j].next){    //搜索u的所有邻接边
                    if(E[j].cap>E[j].flow)                  //有可增量
                        hmin=Math.min(hmin,h[E[j].v]);      //取所有邻接点高度的最小值
                }//for

                h[u]=hmin+1;
                ++g[h[u]];                              //重新标高后该高度的结点数+1
                if (u!=s)                               //如果当前结点不是源点
                    u=E[pre[u]^1].v;                    //向前退回一步，重新搜索增广路
            }//if(i==-1)

        }//while
        return ans;
    }

    /*输出网络邻接表*/
    public static void printg(int n){
        System.out.println("-----------网络邻接表如下：-----------");
        for (int i=1;i<=n;i++){
            System.out.print("v"+i+"  ["+V[i].first);

            for (int j=V[i].first;j>=~j;j=E[j].next)
                System.out.print("]--["+E[j].v+"  "+E[j].cap+"  "+E[j].flow+"  "+E[j].next);
            System.out.println("]");
        }
    }

    /*输出实流边(配对结果)*/
    public static void printflow(int n){
        System.out.println("------------配对方案如下：---------------");
        for (int i=1;i<=n;i++)
            for (int j=V[i].first;j>=~j;j=E[j].next)
                if (E[j].flow>0){
                    System.out.println(i+"--"+E[j].v); //只打印配对员工的号码，与E[j].flow无关
                }
    }



    public static void main(String[] args){
        int n,m,total;//多了total
        int u,v,w=1;
        Scanner scanner = new Scanner(System.in);
        System.out.println("请输入女推销员人数m和男推销员人数n: ");

        m=scanner.nextInt();
        n=scanner.nextInt();

        init(n*100,m*100);     //有多种情况，N，M尽量大
        total = m+n;                //统计员工总人数

        System.out.println("请输入可以配合的女推销员编号u和男推销员编号v（两个都为-1结束）,大家期望值默认为1，不输入：");
        for (int i=1;i<=m;i++){
            add(0,i,w);         //源点到女推销员的边
        }
        for (int j=m+1;j<=total;j++){
            add(j,total+1,w);   //男推销员到汇点的边
        }

        u=scanner.nextInt();
        v=scanner.nextInt();
        while (u+v!=-2){
            add(u,v,1);
            u=scanner.nextInt();
            v=scanner.nextInt();
        }

        System.out.println();

        //对应：“网络的最大流值”
        System.out.println("最大配对数："+Isap(0,total+1,total+2));
        System.out.println();

        printflow(m);           //输出实流边——这个才是配对的v
    }
}

