package Algorithm.Chapter7._7_5;
/*7.5.7精明的老板——配对方案问题:使用匈牙利算法--/*匈牙利算法:简练版本*/
import java.util.Arrays;
import java.util.Scanner;


public class Matching {
    static int top;
    static int match[];
    static boolean[] vis;
    static Vertex[] V;
    static Edge[] E;

    /*初始化，因为配对的结点较多，要对数组长度扩倍*/
    static void init(int N,int M){              //N=n*10; M=m*10
        match=new int[N];   //默认为0
        vis=new boolean[N]; //默认为false
        V=new Vertex[M];
        E=new Edge[M];
        top=0;

        //对象生成不能使用Arrays.fill(),只能用循环
        for (int i=0;i<V.length;i++){
            V[i]=new Vertex(-1);
        }
        for (int i=0;i<E.length;i++){
            E[i]=new Edge();
        }
    }

    /*结点类*/
    public static class Vertex{
        int first;
        Vertex(int first){
            this.first=first;
        }
    }
    /*边类*/
    public static class Edge{
        int v,next;
    }

    /*创建边*/
    public static void add(int u,int v){
        //输入数据格式：u,v以及边(u--v)
        E[top].v=v;                   //访问的对方结点
        E[top].next=V[u].first;      //下一个结点设为u下一个结点v
        V[u].first=top++;           //u结点指向top结点，也就是v值，然后++top跳到下一个结点v
    }

    /*输出网络邻接表*/
    public static void printg(int n){
        System.out.println("-----------邻接表如下：-----------");
        for (int i=1;i<=n;i++){
            System.out.print("v"+i+"  ["+V[i].first);

            for (int j=V[i].first;j>-1;j=E[j].next) //j从起点开始，避开为点为-1的地方，进行寻找
                System.out.print("]--["+E[j].v+"  "+E[j].next);
            System.out.println("]");
        }
    }

    /*输出配对方案*/
    public static void printflow(int n){
        System.out.println("------------配对方案如下：---------------");
        for (int i=1;i<=n;i++)
            if (match[i]!=0){        //配对的员工号没有0的
                System.out.println(i+"--"+match[i]);
            }
    }

    /*匈牙利算法:为u找匹配点，找到返回true，否则返回false*/
    public static boolean hungarian(int u){
        int v=0;
        for (int j=V[u].first;j>-1;j=E[j].next){ //j从起点开始，避开为点为-1的地方，进行寻找
            v = E[j].v;    //u的邻接点v
            if (!vis[v]){   //v还没有被访问
                vis[v]=true;    //v标记访问
                if (match[v]==0 || hungarian(match[v])){
                    match[u]=v;
                    match[v]=u;
                    return true;
                }
            }
        }
        return false;
    }


    public static void main(String[] args){
        int n,m,total,num=0;//多了total和num
        int u,v;
        Scanner scanner = new Scanner(System.in);
        System.out.println("请输入女推销员人数m和男推销员人数n: ");

        m=scanner.nextInt();
        n=scanner.nextInt();

        init(n*100,m*100);  //有多种情况，N，M尽量预设大一点

        total = m+n;                //统计员工总人数

        System.out.println("请输入可以配合的女推销员编号u和男推销员编号v（两个都为-1结束）：");
        u=scanner.nextInt();
        v=scanner.nextInt();
        while (u+v!=-2){
            add(u,v);
            add(v,u);
            u=scanner.nextInt();
            v=scanner.nextInt();
        }

        System.out.println();

        printg(total);              //输出网络邻接表

        for(int i=1;i<=m;i++){
            //清空搜索标记:这个是重点，千万不能忘记
            Arrays.fill(vis,false);

            if (hungarian(i))
                num++;
        }

        System.out.println("\n最大配对数："+num+"\n");

        printflow(m);           //输出配对方案——这个才是配对的v
    }
}
