package Algorithm.Chapter7._7_5;
/*7.5.7精明的老板——配对方案问题:使用匈牙利算法
* 书本写法，预设数组长度*/

import java.util.Arrays;
import java.util.Scanner;

public class Matching_hungarian {
    static int top;
    static int[] match;         //存储配对结点，默认为0
    static boolean[] vis;       //标记数组，默认为false
    static Vertex[] V;          //结点数组
    static Edge[] E;            //边数组

    /*初始化结点和边*/
    public static void init(int N,int M){
        match=new int[N];
        vis=new boolean[N];
        V = new Vertex[N];
        E = new Edge[M];

        for (int i=0;i<N;i++){
            V[i]=new Vertex(-1);          //初始化邻接表头结点第一个邻接边为-1
        }
        for(int i=0;i<M;i++){
            E[i]=new Edge();
        }
        top=0;
    }

    /*结点结构体*/
    public static class Vertex{
        int first;                      //邻接表头结点第一个邻接边
        Vertex(int first){
            this.first=first;
        }
    }
    /*边结构体*/
    public static class Edge{
        int v,next;
    }

    /*创建边*/
    public static void add(int u,int v){
        //输入数据格式：u v及边（u--v）
        E[top].v=v;
        E[top].next=V[u].first;     //连接到邻接表中
        V[u].first=top++;
    }

    /*为u找匹配点，找到返回true，否则返回false*/
    public static boolean hungarian(int u){
        int v;
        for (int j=V[u].first; j>0; j=E[j].next){
            v = E[j].v;     //u的邻接点v
            if (!vis[v]){
                vis[v]=true;
                if (match[v]==0 || hungarian(match[v])){   //v未匹配或者为v的匹配点找到了其他匹配
                    match[u]=v;
                    match[v]=u;
                    return true;
                }
            }
        }
        return false;                                       //所有邻接边都检查完毕，还没找到匹配点
    }


    /*输出网络邻接表*/
    public static void printg(int n){
        System.out.println("-----------邻接表如下：-----------");
        for (int i=1;i<=n;i++){
            System.out.print("v"+i+"  ["+V[i].first);

            for (int j=V[i].first;j>0;j=E[j].next)
                System.out.print("]--["+E[j].v+"  "+E[j].next);
            System.out.println("]");
        }
    }

    /*输出配对方案*/
    public static void printflow(int n){
        System.out.println("------------配对方案如下：---------------");
        for (int i=1;i<=n;i++)
        if (match[i]!=0){                                   //配对的员工号没有0的
                System.out.println(i+"--"+match[i]);
            }
    }


    public static void main(String[] args){
        int n,m,total,num=0;                    //多了total和num
        int u,v;
        Scanner scanner = new Scanner(System.in);
        System.out.println("请输入女推销员人数m和男推销员人数n: ");

        m=scanner.nextInt();
        n=scanner.nextInt();
        init(n*100,m*100);                //有多种情况，N，M尽量预设大一点
        total = m+n;                            //统计员工总人数

        System.out.println("请输入可以配合的女推销员编号u和男推销员编号v（两个都为-1结束）：");
        u=scanner.nextInt();
        v=scanner.nextInt();
        while (u+v!=-2){
            add(u,v);                   //要加双向的边
            add(v,u);
            u=scanner.nextInt();
            v=scanner.nextInt();
        }

        System.out.println();

        printg(total);                  //输出网络邻接表

        for(int i=1;i<=m;i++){
            //清空搜索标记:这个是重点，千万不能忘记
            Arrays.fill(vis,false);

            boolean flag = hungarian(i);
            if (flag)
                num++;
        }

        System.out.println();

        System.out.println("\n最大配对数："+num+"\n");

        printflow(m);           //输出配对方案——这个才是配对的v
    }
}


