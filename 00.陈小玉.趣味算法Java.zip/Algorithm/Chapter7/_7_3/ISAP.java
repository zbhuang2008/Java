package Algorithm.Chapter7._7_3;
/*7.3.7 算法优化拓展——重贴标签算法ISAP：使用邻接表
* 比较详细，打印了邻接表和一些具体信息*/

import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class ISAP {
    static final double INF=Double.POSITIVE_INFINITY;
    static final int N=100;
    static int top;
    static int[] h;          //h[]数组记录每个结点的高度，即到汇点的最短距离。
    static int[] g;          //g[]数组记录距离为h[]的结点的个数，例如g[3]=1，表示距离为3的结点个数为1个
    static int[] pre;       // pre[]记录当前结点的前驱边，pre[v]=i，表示结点v的前驱边为i，即搜索路径入边
    static Vertex[] V;      //结点数组
    static Edge[] E;        //边数组

    /*初始化*/
    public static void init(int N){
        h=new int[N];
        g=new int[N];
        pre=new int[N];
        V=new Vertex[N];
        E=new Edge[N];

        for (int i=0;i<N;i++){
            V[i]=new Vertex(-1);                        //初始化邻接表头结点第一个邻接边为-1
            E[i]=new Edge();
        }
        top=0;
    }

    //结点结构体
    public static class Vertex{
        int first;                      //邻接表头结点第一个邻接边
        Vertex(int first){
            this.first=first;
        }
    }
    //边结构体
    public static class Edge{
        int v,next;
        int cap,flow;
    }

    /*创建边*/
    public static void add_edge(int u,int v,int c){
        //输入数据格式：u v及边（u--v）的容量c
        E[top].v=v;
        E[top].cap=c;
        E[top].flow=0;
        E[top].next=V[u].first;     //连接到邻接表中
        V[u].first=top++;
    }

    /*添加两条边,因为是有向图，u->v:权值=c; v->u不存在，权值设置为0*/
    public static void add(int u,int v,int c){
        add_edge(u,v,c);
        add_edge(v,u,0);
    }

    /*标高函数——使用bfs广度优先搜索*/
    public static void set_h(int t,int n){
        Queue<Integer> Q = new LinkedList<>();          //创建bfs用的队列
        Arrays.fill(h,-1);                          //重点：对h[],g[]清空
        Arrays.fill(g,0);
        h[t]=0;                                         //初始化汇点高度为0
        Q.add(t);                                       //入队
        while (!Q.isEmpty()){
            int v = Q.poll();
            ++g[h[v]];
            for (int i = V[v].first; i>=~i; i=E[i].next){   //读结点v的邻接边标号:注意是大于等于自反值
                int u = E[i].v;
                if (h[u]==-1){
                    h[u]=h[v]+1;
                    Q.add(u);
                }
            }
        }//while
        System.out.println("初始化高度：");
        System.out.print("h[ ]=");
        for (int i=1;i<=n;i++)
            System.out.print(" "+h[i]);
        System.out.println();

    }

    public static int Isap(int s,int t,int n){
        set_h(t,n);                                         //标高函数
        int ans=0;
        int u=s;
        double d = 0;

        while (h[s]<n){
            int i = V[u].first;                             //while中的i统一使用这个

            if (u==s)
                d=INF;

            for(;i>=~i;i=E[i].next){
                int v=E[i].v;                                //搜索当前结点的邻接边
                if (E[i].cap > E[i].flow && h[u]==h[v]+1){  //沿有可增量和高度减1的方向搜索
                    u=v;
                    pre[v]=i;
                    d=Math.min(d,E[i].cap-E[i].flow);       //最小增量

                    if (u==t){
                        System.out.print("\n增广路径："+t);
                        while (u!=s){                   //从汇点向前，沿增广路径一直搜索到源点
                            int j=pre[u];              //j为u的前驱边，即增广路上j为u的入边
                            E[j].flow+=d;             //j边的流量+d
                            E[j^1].flow-=d;           //j的反向边的流量-d
                            u=E[j^1].v;
                            System.out.print("--"+u);   /*j^1表示j和1的"与运算"，因为创建边时是成对创建的，
                                                        *0号边的反向边是1号，二进制0和1的与运算正好是1号，
                                                        *即2号边的反向边是3，二进制10和1的与运算正好是11，
                                                        *即3号，因此当前边号和1的与运算可以得到当前边的反向边。
                                                        */
                        }//while

                        System.out.println("增流: "+d);
                        ans+=d;
                        d=INF;

                    }//小if
                    break;                           //找到一条可行邻接边，退出for语句，继续向前走
                }//大if
            }//for

            if (i==-1){                             //当前结点的所有邻接边均搜索完毕，无法行进
                if (--g[h[u]]==0)                   //如果该高度的结点只有一个，算法结束
                    break;
                int hmin=n-1;
                for (int j=V[u].first;j>=~j;j=E[j].next){    //搜索u的所有邻接边
                    if(E[j].cap>E[j].flow)                  //有可增量
                        hmin=Math.min(hmin,h[E[j].v]);      //取所有邻接点高度的最小值
                }//for

                h[u]=hmin+1;
                System.out.println("重贴标签后高度：");
                System.out.print("h[ ]=");
                for (int j=1;j<=n;j++)
                    System.out.print(" "+h[j]);
                System.out.println();
                ++g[h[u]];                              //重新标高后该高度的结点数+1
                if (u!=s)                               //如果当前结点不是源点
                    u=E[pre[u]^1].v;                    //向前退回一步，重新搜索增广路
            }//if(i==-1)

        }//while
        return ans;
    }

    /*输出网络邻接表*/
    public static void printg(int n){
        System.out.println("-----------网络邻接表如下：-----------");
        for (int i=1;i<=n;i++){
            System.out.print("v"+i+"  ["+V[i].first);

            for (int j=V[i].first;j>=~j;j=E[j].next)
                System.out.print("]--["+E[j].v+"  "+E[j].cap+"  "+E[j].flow+"  "+E[j].next);
            System.out.println("]");
        }
    }

    /*输出实流边*/
    public static void printflow(int n){
        System.out.println("------------实流边如下：---------------");
        for (int i=1;i<=n;i++)
            for (int j=V[i].first;j>=~j;j=E[j].next)
                if (E[j].flow>0){
                    System.out.println("v"+i+"--v"+E[j].v+"  "+E[j].flow);
                }
    }


    public static void main(String[] args){
        int n,m;
        int u,v,w;
        Scanner scanner = new Scanner(System.in);
        System.out.println("请输入结点个数n和边数m: ");

        n=scanner.nextInt();
        m=scanner.nextInt();

        init(n*n);          //初始化:因为有多种情况，N尽量大

        System.out.println("请输入两个结点u,v及边(u--v)的容量w: ");
        for (int i=1;i<=m;i++){
            u=scanner.nextInt();
            v=scanner.nextInt();
            w=scanner.nextInt();
            add(u,v,w);         //添加两条边
        }
        System.out.println();
        printg(n);              //输出初始网络邻接表
        System.out.println("网络的最大流值："+Isap(1,n,n));
        System.out.println();

        printg(n);              //输出最终网络
        printflow(n);           //输出实流边

    }
}
