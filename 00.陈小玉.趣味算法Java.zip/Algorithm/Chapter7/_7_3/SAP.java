package Algorithm.Chapter7._7_3;
/*7.3.5未优化：最大网络流——最短增广路算法*/
import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

/*通过bfs来求有向网的网络最大流——即找可增广路*/
public class SAP {
    static final double INF=Double.POSITIVE_INFINITY;        //无穷大
    static int[][]g;                                        //残余网络(初始时各边为容量)
    static int[][]f;                                        //实流网络(初始时各边为0流)
    static int[]pre;                                        //前驱数组
    static boolean[] vis;                                   //访问数组
    static int n,m;                                         //结点个数和边的数量

    static void init(int N){                                //N=n*n;
        g=new int[N][N];
        f=new int[N][N];
        pre=new int[N];
        vis=new boolean[N];

    }

    /*广度优先遍历：每次遍历都要清空pre和vis数组*/
    public static boolean bfs(int s,int t){

        Arrays.fill(pre,-1);
        Arrays.fill(vis,false);

        Queue<Integer> q=new LinkedList<>();      //bfs所用队列
        vis[s]=true;                             //起点标记为true
        q.add(s);                                //加入起点
        while (!q.isEmpty()){
            int now =q.poll();
            for (int i=1;i<=n;i++){             //遍历所有结点，寻找可增广路
                if (!vis[i] && g[now][i]>0){    //未被访问且有边相连
                    vis[i] = true;
                    pre[i] = now;
                    if (i==t) return true;      //找到一条可增广路
                    q.add(i);
                }
            }
        }//while
        return false;                           //找不到可增广路
    }

    public static double EK(int s,int t){
        double maxflow = 0;                     //要return maxflow
        int v,w;
        double d;

        while (bfs(s,t)){                      //可以增广
            v=t;
            d=INF;
            while (v!=s){                       //找可增量d
                w = pre[v];                 //w记录v的前驱
                if (d>g[w][v])
                    d=g[w][v];
                v=w;
            }//小while

            maxflow+=d;
            v=t;
            while (v!=s){                       //沿着可增广路增流
                w=pre[v];
                g[w][v]-=d;
                g[v][w]+=d;
                if (f[v][w]>0)
                    f[v][w]-=d;
                else
                    f[w][v]+=d;
                v=w;
            }

        }//大while

        return maxflow;
    }

    public static void print(){
        System.out.println("----------实流网络如下：------------");
        System.out.print(" ");
        for (int i=1;i<=n;i++)
            System.out.printf("%7s","v"+i);
        System.out.println();

        for (int i=1;i<=n;i++){
            System.out.print("v"+i);
            for (int j=1;j<=n;j++)
                System.out.printf("%7s",f[i][j]+" ");
            System.out.println();
        }
    }

    public static void main(String[] args){
        int u,v,w;
        Scanner scanner = new Scanner(System.in);

        //残余网络和实流初始网络已经为0，故不用初始化
        System.out.println("请输入结点个数n和边数m:");
        n=scanner.nextInt();
        m=scanner.nextInt();

        init(n*n);      //因为有多种情况，N尽量大

        System.out.println("请输入两个结点u,v及边(u--v)的容量w:");
        for (int i=1;i<=m;i++){
            u=scanner.nextInt();
            v=scanner.nextInt();
            w=scanner.nextInt();
            g[u][v]+=w;
        }

        System.out.println("网络的最大流值："+EK(1,n));
        print();
    }
}
