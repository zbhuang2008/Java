package Algorithm.Chapter2._2_2;
/*2.2加勒比海盗船——最优装载问题*/
import java.util.Scanner;
import java.util.Arrays;

public class Test2_2 {
    static int[] weight;
    static int n;
    static double c;

    static void init(int N){                        //N=n
        weight=new int[N];
    }

    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        System.out.println("请输入载重量c及古董个数n：");
        c=scanner.nextDouble();                         //载重量
        n=scanner.nextInt();                           //古董个数

        init(n);

        System.out.println("请输入每个古董的重量：");
        for(int i=0;i<n;i++)
            weight[i]=scanner.nextInt();

        Arrays.sort(weight);                                //对古董重量数组升序排序

        int temp=0;                                        //记录装载到船上的古董重量
        int answer=0;                                      //记录已装载的古董个数
        for(int i=0;i<n;i++) {
            temp+=weight[i];                               //贪心策略：每次装入最轻者
            if(temp<=c)                                    //若加入最轻者后还小于载重量，则古董个数+1
                answer++;
            else
                break;
        }

        System.out.println("能装入的古董最大数量为answer="+answer);
        scanner.close();
    }
}

