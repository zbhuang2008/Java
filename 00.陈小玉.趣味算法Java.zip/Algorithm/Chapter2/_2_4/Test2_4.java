package Algorithm.Chapter2._2_4;
/*2.4高级钟点秘书——会议安排*/
import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

public class Test2_4 {
    static Meet[] meet;
    static int n;               //会议总数
    static int ans;             //最大安排的会议总数


    static void init(int N){   //N=n,会议有多少就设多少，不预设最大会议总数1000了
        meet=new Meet[N];
        for (int i=0;i<N;i++){
            meet[i]=new Meet();
        }
    }

    static class Meet{
        int beg;            //预约的开始时间
        int end;            //结束时间
        int num;            //会议数量
    }

    /*自定义排序: 对会议按结束时间排序,当结束时间相同，按开始时间排序*/
    static class cmp<A extends Meet> implements Comparator<A> {
        @Override
        public int compare(A x, A y) {
            if (x.end < y.end)
                return -1;
            else if (x.end > y.end)
                return 1;
            else
                return x.beg-y.beg;

        }
    }

    static void setMeet(){
        int s,e;
        Scanner scanner=new Scanner(System.in);
        System.out.println("输入会议总数");
        n=scanner.nextInt();

        init(n);                    //初始化会议总数

        System.out.println("输入会议的开始时间和结束时间（以空格分开）：");
        for (int i=0;i<n;i++){
            s=scanner.nextInt();
            e=scanner.nextInt();
            meet[i].beg=s;
            meet[i].end=e;
            meet[i].num=i+1;    //会议数从1开始，不是从0开始，故+1
        }
    }

    static void solve(){
        Arrays.sort(meet,new cmp());
        System.out.println("排完序的会议时间如下：");
        System.out.println("会议编号  开始时间  结束时间");
        for (int i=0; i<n; i++){
            System.out.println("\t"+meet[i].num+"\t\t"+meet[i].beg+"\t\t"+meet[i].end);
        }
        System.out.println("-------------------------------------------------");
        System.out.println("选择会议的过程：");
        System.out.println(" 选择第"+meet[0].num+"个会议");       //选中了第一个会议
        ans=1;                                                  //最大安排的会议总数是1
        int last=meet[0].end;                                   //记录刚刚被选中会议的结束时间
        for (int i=1;i<n;i++){
            if (meet[i].beg >= last){                          //如果会议i开始时间大于等于最后一个选中的会议的结束时间
                ans++;
                last = meet[i].end;
                System.out.println(" 选择第"+meet[i].num+"个会议");
            }
        }
        System.out.println("最多可以安排"+ans+"个会议");
    }


    public static void main(String[] args) {
        setMeet();
        solve();
    }
}


