package Algorithm.Chapter2._2_5;
/*2.5一场说走就走的旅行——最短路径：未优化*/
import java.util.Scanner;
import java.util.Stack;

/*2.5一场说走就走的旅行——最短路径::Dijkstra算法*/
public class Test2_5 {
    static final double INF=Double.POSITIVE_INFINITY;   //无穷大
    static double[][] map;                              //地图保存路径权值
    static double[] dist;
    static int[] p;
    static boolean[] flag;
    static int n,m;

    static void init(int N){                //N=n+1
        map=new double[N][N];
        dist=new double[N];
        p=new int[N];
        flag=new boolean[N];

        //初始化图map为INF
        for(int i=0;i<N;i++)
            for (int j=0;j<N;j++)
                map[i][j]=INF;
    }

    /*输入起点，执行Dijkstra算法*/
    static void Dijkstra(int u){
        for (int i=1;i<=n;i++){
            dist[i]= map[u][i];         //初始化源点u到其他各个顶点的最短路径长度
            flag[i]=false;
            if (dist[i]==INF)
                p[i]=-1;                //源点u到该顶点的路径长度为无穷大，说明顶点i与源点u不相邻
            else
                p[i]=u;                 //说明顶点i与源点u相邻，设置顶点i的前驱p[i]=u
        }
        dist[u]=0;
        flag[u]=true;                   //初始时，集合S中只有一个元素：源点u

        for (int i=1;i<=n;i++){         //②
            double temp=INF;            //temp用来置换出最小路径(权值)
            int t=u;

            for (int j=1;j<=n;j++){     //③在集合V-S中寻找距离源点u最近的顶点t
                if (!flag[j] && dist[j]<temp){
                    temp=dist[j];
                    t=j;                    //t承接当前的结点位置
                    if (t==u) return;       //找不到t，跳出循环
                    flag[t]=true;           //否则，将t加入集合
                }

                for (int z=1;z<=n;z++){ //④//更新集合V-S中与t邻接的顶点到源点u的距离
                    if (!flag[z] && map[t][z]<INF)  //!s[j]表示j在V-S中
                        if (dist[z]>(dist[t]+map[t][z])){
                            dist[z]=dist[t]+map[t][z];
                            p[z]=t;
                        }
                }
            }//第2for

        }//第1for
    } //Dijkstra

    /*记录前驱结点*/
    static void findPath(int u){
        int x;
        Stack<Integer> s =new Stack<>();
        System.out.println("源点为："+u);
        for (int i=1;i<=n;i++){
            x=p[i];
            while (x!=-1){
                s.push(x);
                x=p[x];
            }
            System.out.print("源点到其他各顶点的最短路径为：");
            while (!s.isEmpty()){
                System.out.print(s.pop()+"--");     //依次取栈顶元素
            }
            System.out.print(i+";最短距离为："+dist[i]+"\n");
        }
    }

    public static void main(String[] args){
        int u,v,w,st;
        Scanner scanner=new Scanner(System.in);
        System.out.println("请输入城市的个数:");
        n=scanner.nextInt();

        System.out.println("请输入城市之间的路线个数：");
        m=scanner.nextInt();

        init(n+1);        //初始化:已经包含地图邻接矩阵初始化,因为从下标1~n算，故传n+1

        System.out.println("请输入城市之间的路线以及距离：");
        while ((m--)!=0){
            u=scanner.nextInt();
            v=scanner.nextInt();
            w=scanner.nextInt();
            map[u][v]=Math.min(map[u][v],w);    //邻接矩阵储存，保留最小的距离
        }

        System.out.println("请输入小明所在的位置：");
        st=scanner.nextInt();

        //执行Dijkstra算法
        Dijkstra(st);
        System.out.println("小明所在位置：");
        findPath(st);

    }
}

