package Algorithm.Chapter2._2_5._2_5_2;
/*2.5一场说走就走的旅行——最短路径：已经优化，使用最小优先队列*/

import java.util.Arrays;
import java.util.Scanner;
import java.util.Stack;

public class Test_2_5_2 {
    static final double INF=Double.POSITIVE_INFINITY;
    static double[][] map;
    static double[] dist;
    static boolean[] flag;
    static int n,m;

    /*初始化*/
    static void init(int N){        //N=n+1
        map=new double[N][N];
        dist=new double[N];
        flag=new boolean[N];

        //初始化地图为INF
        for(int i=0;i<N;i++)
            for (int j=0;j<N;j++)
                map[i][j]=INF;
    }

    /*结点类*/
    static class Node implements Comparable<Node> {
        int u;
        double step;
        Node(int u,double step){
            this.u=u;
            this.step=step;
        }

        /*升序排序*/
        @Override
        public int compareTo(Node a) {
            if (this.step<a.step)       //升序排序，return -1;
                return -1;
            if (this.step>a.step)
                return 1;
            else
                return 0;
        }
    }

    static void Dijkstra(int u){
        MinPriorityQueue<Node> Q=new MinPriorityQueue<>(n*2);   //初始化最小优先队列
        Q.insert(new Node(u,0));
        Arrays.fill(flag,false);                        //初始化flag为false
        Arrays.fill(dist,INF);                              //初始化距离无穷大

        dist[u]=0;                                          //起点距离标记为0

        while (!Q.isEmpty()){
            Node it=Q.delMin();                             //取出并删除最小优先队列的根，也就是step最小值结点
            int t = it.u;
            if (!flag[t])                                    //说明已经找到了最短距离，该结点是队列里面的重复元素
                flag[t]=true;                               //标记该最短距离的结点t
            else
                continue;


            //核心：松弛操作
            for (int i=1;i<=n;i++){
                if (!flag[i] && map[t][i] < INF){           //判断与当前点有关系的点，并且自己不能到自己
                    if (dist[i]>dist[t]+map[t][i]){
                                                            //求距离当前点的每个点的最短距离，进行松弛操作
                        dist[i] = dist[t]+map[t][i];
                        Q.insert(new Node(i,dist[i]));      // 把更新后的最短距离压入优先队列，注意：里面的元素有重复
                    }
                }
            }
        }
    }

    /*记录前驱结点*/
    static void findPath(int u){
        System.out.println("源点为："+u);
        for (int i=1;i<=n;i++){
            System.out.print("小明："+u+"---要去的位置："+i);
            if (dist[i]==INF)
                System.out.print(" 抱歉，无路可达！\n");
            else
                System.out.print(" 最短距离为："+dist[i]+"\n");


        }
    }


    public static void main(String[] args){
        int u,v,w,st;
        Scanner scanner=new Scanner(System.in);

        System.out.println("请输入城市的个数：");
        n=scanner.nextInt();
        System.out.println("请输入城市之间的路线的个数：");
        m=scanner.nextInt();
        //初始化
        init(n+1);  //因为从1~n遍历，故设为n+1

        System.out.println("请输入城市之间u,v的路线以及距离w:");
        while ((m--)!=0){
            u=scanner.nextInt();
            v=scanner.nextInt();
            w=scanner.nextInt();
            map[u][v]=Math.min(map[u][v],w);                //邻接矩阵储存，保留最小的距离
        }

        System.out.println("请输入小明所在的位置：");
        st=scanner.nextInt();

        //执行Dijkstra算法
        Dijkstra(st);
        System.out.println("小明所在位置：");
        findPath(st);
    }
}
