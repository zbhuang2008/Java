package Algorithm.Chapter2._2_3;
/*2.3阿里巴巴与四十大盗——背包问题:引用Comparator接口：算书本给出的数据是24.6,
 *但换成背包问题的其它数据，出现很大的差别
* */
import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

public class Test2_3 {
    static three[] s;
    static int n;
    static double m;
    static double sum;

    static void init(int n){
        s=new three[n];

        for(int i=0;i<n;i++){
            s[i]=new three();
        }
    }

    public static class three {
        double w;               //每个宝物的重量
        double v;               //每个宝物的价值
        double p;               //性价比
    }

    /*按[价值重量比]降序排序*/
    public static class cmp<A extends three> implements Comparator<A>{
        @Override
        public int compare(A a, A b) {
            if (a.p > b.p){
                return -1;
            }else if (a.p < b.p){
                return 1;
            }else{
                return 0;
            }
        }
    }


    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);

        System.out.println("请输入宝物数量n及毛驴的承载能力m：");
        n=scanner.nextInt();               //表示n个宝物
        m=scanner.nextDouble();         //表示毛驴的承载能力

        init(n);

        System.out.println("请输入每个宝物的重量和价值，用空格分开：");

        //定义n长的数组存放宝物，数组类型是three型，即数组每位由重量、价格和性价比组成
        for(int i=0;i<n;i++) {
            s[i].w=scanner.nextDouble();
            s[i].v=scanner.nextDouble();
            s[i].p=s[i].v/s[i].w;               ////[价值重量比]
        }

        Arrays.sort(s,new cmp());

        sum=0;                          //表示贪心记录运走宝物的价值之和
        for(int i=0;i<n;i++) {
            if(m>s[i].w) {                     //如果宝物的重量小于毛驴剩下的承载能力
                m-=s[i].w;                     //毛驴承载能力减少
                sum+=s[i].v;                   //宝物价值之和增加
            }
            else {                              //如果宝物的重量大于毛驴剩下的承载能力，则进行部分装载
                sum+=m*s[i].p;                 //价值增加部分重量的价值
                break;
            }
        }

        System.out.println("装入宝物的最大价值Maximum value="+sum);
    }
}