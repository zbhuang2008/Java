package Algorithm.Chapter2._2_7;
/*2.7沟通无限校园网——最小生成树：已经优化*/
import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;


public class Test2_7_2 {
    static int[] nodeset;                                 //存放结点的集合号
    static Edge[] edge;
    static int n,m;

    public static void init(int N) {                     //N=n+1
        nodeset=new int[N];
        edge=new Edge[N*N];

        for(int i=1;i<=n;i++)                           //注意：只对1~n的部位初始化
            nodeset[i]=i;                               //每个结点对应一个集合
    }

    static class Edge {
        int u;               //边的前驱端点u
        int v;              //边的后继端点v
        double w;           //权值w
    }

    static class cmp<A extends Edge> implements Comparator<A>{
        //自定义排序对边权值从小到大排序(升序)
        @Override
        public int compare(A x, A y) {
            if (x.w<y.w)                  //满足升序排序，return -1;
                return -1;
            else if (x.w>y.w)
                return 1;
            else
                return 0;
        }
    }

    public static double Kruskal(int n,int m,Edge[] e) {
        double ans=0;
        int j=0;                                                       //用来控制已加入的边数
        for(int i=0;i<m;i++) {
            if(merge(e[i].u,e[i].v,n)) {                              //判断边的两端是否属于同一集合即是否构成回路
                ans+=e[i].w;                                          //若不构成回路则将改变加入
                if(++j==(n-1))                                        //加入n-1条边即可
                    return ans;
            }
        }
        return 0;
    }

    public static boolean merge(int u,int v,int n) {                  //合并集合
        int p=nodeset[u];                                             //p为u结点的集合号
        int q=nodeset[v];                                             //去为v结点的集合号
        if(p==q)                                                      //说明u和v在一个集合中
            return false;
        for(int i=1;i<=n;i++) {
            if(nodeset[i]==q)
                nodeset[i]=p;                                         //将和v相同的集合中的结点改为u的集合号
        }
        return true;
    }

    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        System.out.println("输入结点数n和边数m：");
        n=scanner.nextInt();
        m=scanner.nextInt();
        Edge[] e=new Edge[m];                                         //存放m条边

        init(n+1);                                                //初始化

        System.out.println("输入结点数u、v和边值w：");
        for(int i=0;i<m;i++) {
            e[i]=new Edge();
            e[i].u=scanner.nextInt();
            e[i].v=scanner.nextInt();
            e[i].w=scanner.nextDouble();
        }

        Arrays.sort(e,new cmp());                                   //将边按权值从小到大排序
        double ans=Kruskal(n,m,e);
        System.out.println("最小的花费是："+ans);
    }
}

